import json
from datetime import datetime


def generate_youtube_bundle(project: dict) -> str:
    keyword = project.get("keyword", "untitled")
    now = datetime.utcnow().strftime("%Y-%m-%d")

    alt_titles_raw = project.get("alt_titles", "") or ""
    alt_titles = [t.strip() for t in alt_titles_raw.split("\n") if t.strip()]

    tags_raw = project.get("tags", "") or ""
    tags = [t.strip() for t in tags_raw.split(",") if t.strip()]

    pivot_raw = project.get("pivot_strategy", "") or ""
    try:
        pivot = json.loads(pivot_raw) if pivot_raw else {}
    except Exception:
        pivot = {}

    lines = [
        "=" * 70,
        f"  YOUTUBE UPLOAD BUNDLE",
        f"  Keyword : {keyword}",
        f"  Generated : {now}",
        "=" * 70,
        "",
        "━━━ ① SEO ARCHITECTURE ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        "",
        "PRIMARY TITLE",
        f"  {project.get('seo_title', '')}",
        "",
    ]

    if alt_titles:
        lines.append("ALT TITLES  (A/B test — swap weekly)")
        for i, t in enumerate(alt_titles, 1):
            lines.append(f"  [{i}] {t}")
        lines.append("")

    desc = project.get("description_snippet", "") or ""
    if desc:
        lines += [
            "DESCRIPTION SNIPPET  (paste as first lines of description)",
            f"  {desc}",
            "",
        ]

    if tags:
        lines += [
            f"TAGS  ({len(tags)} tags)",
            "  " + ", ".join(tags),
            "",
        ]

    lines += [
        "━━━ ② PRODUCTION PARAMETERS ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        "",
        f"  BPM    : {project.get('bpm', '—')}",
        f"  Key    : {project.get('musical_key', '—')}",
        f"  Mood   : {project.get('mood', '—')}",
        f"  Energy : {project.get('energy', '—')} / 10",
        "",
    ]

    sonauto = project.get("sonauto_prompt", "") or ""
    if sonauto:
        lines += [
            "SONAUTO PROMPT  (paste into Sonauto → free vocal generation)",
            f"  {sonauto}",
            "",
        ]

    audiocraft = project.get("audiocraft_prompt", "") or ""
    if audiocraft:
        lines += [
            "AUDIOCRAFT / MUSICGEN PROMPT  (local / open-source)",
            f"  {audiocraft}",
            "",
        ]

    lines += [
        "━━━ ③ PIVOT STRATEGY ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        "",
        f"  Success Target  : {pivot.get('success_target', 'Rank #5 within 14 days')}",
        f"  If Rank Fails   : {pivot.get('if_rank_fails', '—')}",
        f"  Thumbnail Tip   : {pivot.get('thumbnail_tip', '—')}",
        "",
    ]

    notes = project.get("notes", "") or ""
    if notes:
        lines += [
            "━━━ NOTES ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
            "",
            f"  {notes}",
            "",
        ]

    lines += [
        "=" * 70,
        f"  Gap Score : {project.get('gap_score', '—')}",
        f"  Status    : {project.get('status', '—')}",
        f"  Created   : {project.get('created_at', '—')}",
        "=" * 70,
    ]

    return "\n".join(lines)


def safe_filename(keyword: str) -> str:
    clean = "".join(c if c.isalnum() or c in " _-" else "_" for c in keyword)
    clean = clean.strip().replace(" ", "_")
    return f"{clean[:60]}_youtube_bundle.txt"
