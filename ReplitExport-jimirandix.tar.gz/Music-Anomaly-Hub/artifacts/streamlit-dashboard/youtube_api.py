import os
import re
from datetime import datetime, timezone
from googleapiclient.discovery import build

YOUTUBE_API_KEY = os.environ.get("YOUTUBE_API_KEY", "")
STALE_DAYS_THRESHOLD = 3 * 365  # 3 years

MUSIC_PREFIXES = [
    "Music for", "Songs for", "Background music for",
    "Instrumental for", "Playlist for", "Relaxing music for",
    "Study music for", "Sleep music for", "Focus music for",
    "Ambient music for", "Meditation music for", "Workout music for",
]

SEED_KEYWORDS = [
    "coding", "studying", "sleeping", "relaxing", "reading",
    "working from home", "yoga", "meditation", "deep focus",
    "anxiety relief", "grief", "rain sounds", "journaling",
    "cooking", "road trips", "morning routine", "coffee shop",
    "writing", "late night", "baby sleep", "napping",
    "video games", "painting", "stretching", "healing",
    "sad nights", "motivation", "walking", "studying late",
]


def get_youtube_client():
    if not YOUTUBE_API_KEY:
        raise ValueError("YOUTUBE_API_KEY environment variable not set.")
    return build("youtube", "v3", developerKey=YOUTUBE_API_KEY)


def parse_iso_date(date_str):
    if not date_str:
        return None
    try:
        dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
        return dt.replace(tzinfo=timezone.utc)
    except Exception:
        return None


def video_age_days(published_str):
    dt = parse_iso_date(published_str)
    if not dt:
        return 0
    now = datetime.now(timezone.utc)
    return (now - dt).days


def search_videos_for_keyword(youtube, keyword, max_results=5):
    try:
        search_resp = youtube.search().list(
            q=keyword,
            part="snippet",
            type="video",
            maxResults=max_results,
            order="relevance",
            videoCategoryId="10",
        ).execute()
    except Exception:
        search_resp = youtube.search().list(
            q=keyword,
            part="snippet",
            type="video",
            maxResults=max_results,
            order="relevance",
        ).execute()

    items = search_resp.get("items", [])
    if not items:
        return []

    video_ids = [i["id"]["videoId"] for i in items if "videoId" in i.get("id", {})]
    if not video_ids:
        return []

    stats_resp = youtube.videos().list(
        part="statistics,snippet,contentDetails",
        id=",".join(video_ids),
    ).execute()

    results = []
    for item in stats_resp.get("items", []):
        snippet = item.get("snippet", {})
        stats = item.get("statistics", {})
        published = snippet.get("publishedAt", "")
        age_days = video_age_days(published)
        view_count = int(stats.get("viewCount", 0))
        like_count = int(stats.get("likeCount", 0))

        results.append({
            "video_id": item["id"],
            "title": snippet.get("title", ""),
            "published": published,
            "age_days": age_days,
            "view_count": view_count,
            "like_count": like_count,
            "channel": snippet.get("channelTitle", ""),
        })

    return results


def compute_gap_score(age_days, view_count, result_count):
    """
    Gap score: older top videos + fewer results = bigger gap opportunity.
    Normalised 0-100.
    """
    age_factor = min(age_days / (STALE_DAYS_THRESHOLD * 2), 1.0)
    view_penalty = min(view_count / 5_000_000, 1.0)
    gap = (age_factor * 0.7 + (1 - view_penalty) * 0.3) * 100
    return round(gap, 2)


def scan_for_gaps(progress_callback=None):
    youtube = get_youtube_client()
    anomalies = []
    keywords = [f"{prefix} {seed}" for prefix in MUSIC_PREFIXES for seed in SEED_KEYWORDS]

    total = len(keywords)
    for i, keyword in enumerate(keywords):
        if progress_callback:
            progress_callback(i, total, keyword)

        try:
            videos = search_videos_for_keyword(youtube, keyword, max_results=5)
        except Exception as e:
            continue

        if not videos:
            continue

        top = videos[0]
        avg_age = sum(v["age_days"] for v in videos) / len(videos)

        if avg_age >= STALE_DAYS_THRESHOLD:
            gap_score = compute_gap_score(
                top["age_days"], top["view_count"], len(videos)
            )
            anomalies.append({
                "keyword": keyword,
                "search_volume_proxy": len(videos),
                "top_video_age_days": top["age_days"],
                "top_video_title": top["title"],
                "top_video_id": top["video_id"],
                "top_video_published": top["published"],
                "top_video_views": top["view_count"],
                "gap_score": gap_score,
                "avg_age_days": round(avg_age),
                "videos": videos,
            })

    anomalies.sort(key=lambda x: x["gap_score"], reverse=True)
    return anomalies


def fetch_my_activities(credentials, max_results: int = 10) -> list[dict]:
    """
    Fetch the most recent video uploads from the authenticated user's channel
    using youtube.activities.list (mine=True, type=upload).

    More reliable than search.list for owned-channel content.
    Returns list of dicts: video_id, title, description, published_at, thumbnail_url
    """
    youtube = build("youtube", "v3", credentials=credentials)
    resp = youtube.activities().list(
        part="snippet,contentDetails",
        mine=True,
        maxResults=50,  # over-fetch; uploads are filtered from mixed activities
    ).execute()

    videos: list[dict] = []
    for item in resp.get("items", []):
        snippet = item.get("snippet", {})
        if snippet.get("type") != "upload":
            continue
        vid_id = (
            item.get("contentDetails", {})
                .get("upload", {})
                .get("videoId", "")
        )
        if not vid_id:
            continue
        thumbs = snippet.get("thumbnails", {})
        thumb  = (thumbs.get("medium") or thumbs.get("default") or {}).get("url", "")
        videos.append({
            "video_id":      vid_id,
            "title":         snippet.get("title", ""),
            "description":   snippet.get("description", ""),
            "published_at":  snippet.get("publishedAt", ""),
            "thumbnail_url": thumb,
        })
        if len(videos) >= max_results:
            break
    return videos


# Keep the old name as an alias so any existing callers don't break
def fetch_my_videos(credentials, max_results: int = 10) -> list[dict]:
    return fetch_my_activities(credentials, max_results)


def fetch_retention_data(
    credentials,
    video_id: str,
    duration_seconds: int = 175,
) -> tuple:
    """
    Fetch the audience retention curve from YouTube Analytics API v2.

    Uses the youtubeAnalytics.v2 reports endpoint with:
        metrics   = audienceWatchRatio
        dimensions= elapsedVideoTimeRatio
        filters   = video==<video_id>

    Returns
    -------
    (df, source) where:
        df      — pd.DataFrame(elapsed_seconds, viewer_percentage)
        source  — 'live'       : real API data
                  'processing' : YouTube hasn't finished processing yet
                  'demo'       : credentials missing or unrecoverable error
    """
    import pandas as pd

    if credentials is None:
        return _make_demo_retention(duration_seconds), "demo"

    try:
        from googleapiclient.discovery import build as ga_build
        analytics = ga_build("youtubeAnalytics", "v2", credentials=credentials)

        resp = analytics.reports().query(
            ids="channel==MINE",
            startDate="2000-01-01",
            endDate="2099-12-31",
            metrics="audienceWatchRatio",
            dimensions="elapsedVideoTimeRatio",
            filters=f"video=={video_id}",
            sort="elapsedVideoTimeRatio",
        ).execute()

        rows = resp.get("rows", [])
        if not rows:
            # Empty result → Analytics hasn't finished processing this video
            return _make_demo_retention(duration_seconds), "processing"

        ratios  = [float(r[0]) for r in rows]
        watch   = [float(r[1]) * 100.0 for r in rows]   # 0–1 → 0–100 %
        seconds = [int(round(ratio * duration_seconds)) for ratio in ratios]
        df = pd.DataFrame({
            "elapsed_seconds":   seconds,
            "viewer_percentage": watch,
        })
        return df, "live"

    except Exception as exc:
        err = str(exc).lower()
        # Surface "processing" on common not-yet-available signals
        if any(k in err for k in (
            "processing", "notfound", "not found",
            "insufficient", "quota", "forbidden", "empty",
        )):
            return _make_demo_retention(duration_seconds), "processing"
        return _make_demo_retention(duration_seconds), "demo"


def _make_demo_retention(duration_seconds: int = 175):
    """Synthetic retention fallback — mirrors retention_viz.make_demo_data()."""
    import math
    import numpy as np
    import pandas as pd
    from scipy.ndimage import gaussian_filter1d

    t          = np.arange(0, duration_seconds + 1)
    decay_rate = -math.log(0.35) / duration_seconds
    base       = 100.0 * np.exp(-decay_rate * t) - 18.0 * np.exp(-0.45 * t)
    base       = np.clip(base, 0, 100)

    bump_center = int(duration_seconds * 0.68)
    base += 6.0 * np.exp(-0.003 * (t - bump_center) ** 2)

    anom_start = min(160, duration_seconds - 1)
    mask = (t >= anom_start) & (t <= duration_seconds)
    if mask.any():
        base[mask] += np.linspace(4.0, 9.0, mask.sum())

    base = gaussian_filter1d(base, sigma=1.8)
    base = np.clip(base, 0, 100)
    return pd.DataFrame({
        "elapsed_seconds":   t.astype(int),
        "viewer_percentage": np.round(base, 4),
    })


def _keyword_from_title(title: str) -> str:
    """Extract a likely search keyword from a video title."""
    import re
    # Capture the 'for ...' subject ("Music for studying" → "studying")
    m = re.search(r"\bfor\s+(.+?)(?:\s*[-|·]|$)", title, re.IGNORECASE)
    if m:
        return m.group(1).strip()
    # Strip common music words and return first 4 remaining words
    noise = {
        "music", "songs", "song", "instrumental", "playlist",
        "relaxing", "ambient", "study", "sleep", "official", "video",
        "audio", "mix", "hour", "hours", "loop",
    }
    words = [w for w in re.split(r"[\s\-|·]+", title) if w.lower() not in noise]
    return " ".join(words[:4]).strip() or title[:50]


def get_video_stats(youtube, video_id):
    resp = youtube.videos().list(
        part="statistics,snippet",
        id=video_id,
    ).execute()
    items = resp.get("items", [])
    if not items:
        return None
    item = items[0]
    stats = item.get("statistics", {})
    snippet = item.get("snippet", {})
    return {
        "view_count": int(stats.get("viewCount", 0)),
        "like_count": int(stats.get("likeCount", 0)),
        "comment_count": int(stats.get("commentCount", 0)),
        "title": snippet.get("title", ""),
        "published": snippet.get("publishedAt", ""),
    }


def get_keyword_rank(youtube, keyword, video_id, max_results=20):
    """Return the rank (1-based) of a video in search results, or None if not found."""
    try:
        resp = youtube.search().list(
            q=keyword,
            part="snippet",
            type="video",
            maxResults=max_results,
            order="relevance",
        ).execute()
        items = resp.get("items", [])
        for idx, item in enumerate(items):
            if item.get("id", {}).get("videoId") == video_id:
                return idx + 1
        return None
    except Exception:
        return None


def compute_success_score(view_count, like_count, comment_count):
    """
    S = R / P  where:
      R = retention proxy = like_rate * comment_engagement
      P = popularity normalised (log scale)
    """
    import math
    if view_count == 0:
        return 0.0
    like_rate = like_count / view_count if view_count > 0 else 0
    comment_rate = comment_count / view_count if view_count > 0 else 0
    R = (like_rate * 0.7 + comment_rate * 0.3)
    P = math.log10(max(view_count, 1)) / 7.0
    if P == 0:
        return 0.0
    S = round(R / P, 6)
    return S


def audit_track(track):
    youtube = get_youtube_client()
    video_id = track["track_youtube_id"]
    keyword = track["keyword"]

    stats = get_video_stats(youtube, video_id)
    if not stats:
        return None

    rank = get_keyword_rank(youtube, keyword, video_id)
    view_count = stats["view_count"]
    like_count = stats["like_count"]
    comment_count = stats["comment_count"]

    days_since_added = 0
    if track.get("added_at"):
        added = parse_iso_date(track["added_at"])
        if added:
            days_since_added = (datetime.now(timezone.utc) - added).days

    retention_estimate = like_count / view_count if view_count > 0 else 0
    popularity_score = view_count / 1_000_000
    success_score = compute_success_score(view_count, like_count, comment_count)

    needs_pivot = (
        rank is None or rank > 10
    ) and days_since_added >= 14

    status = "needs_pivot" if needs_pivot else "monitoring"
    if rank and rank <= 10:
        status = "ranking"

    return {
        "rank": rank,
        "view_count": view_count,
        "like_count": like_count,
        "comment_count": comment_count,
        "retention_estimate": retention_estimate,
        "popularity_score": popularity_score,
        "success_score": success_score,
        "status": status,
        "days_since_added": days_since_added,
    }
