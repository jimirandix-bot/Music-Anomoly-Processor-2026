"""
retention_viz.py — Audience Retention Ridge Plot module.

Public API
----------
fetch_retention_data(credentials, video_id, duration_seconds)
                          — Delegates to youtube_api.fetch_retention_data().
                            Returns (df, source) where source is
                            'live' | 'processing' | 'demo'.
build_ridge_plot(df, ..., data_source='demo')
                          — Render and save the ridge plot.
                            Draws a DATA PENDING overlay when source=='processing'.
                            Shows a LIVE badge when source=='live'.
generate_report(...)      — One-call orchestrator: fetch → plot → save PNG.
                            Returns (output_path, source).
make_demo_data()          — Synthetic retention curve for testing.

YouTube Analytics API
---------------------
viewerPercentage at elapsedVideoTimeRatio requires the YouTube Analytics API v2
(youtubeAnalytics.v2), OAuth 2.0 credentials, and the yt-analytics.readonly scope.
Pass a valid google.oauth2.credentials.Credentials object to generate_report() or
fetch_retention_data().  When credentials are None, or data isn't ready yet,
the plot falls back to demo data with an appropriate overlay.
"""

from __future__ import annotations

import os
import math
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")                       # headless — no display required
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.ticker as ticker
import seaborn as sns
from scipy.ndimage import gaussian_filter1d
from typing import Optional

# ── Constants ────────────────────────────────────────────────────────────────

VIDEO_DURATION_S: int = 175          # 2 min 55 s
ANOMALY_START_S:  int = 160          # 2 min 40 s
ANOMALY_END_S:    int = 175          # 2 min 55 s

COLOR_NORMAL:  str = "#00cc88"       # teal — healthy retention
COLOR_ANOMALY: str = "#ff6b35"       # orange — anomaly marker
COLOR_BG:      str = "#0e0e1a"       # dark background
COLOR_PANEL:   str = "#12122a"
COLOR_TEXT:    str = "#e0e0e0"
COLOR_GRID:    str = "#2a2a3e"

DEFAULT_OUTPUT: str = os.path.join(
    os.path.dirname(__file__), "anomaly_retention_report.png"
)


# ── YouTube Analytics API ─────────────────────────────────────────────────────

def fetch_retention_data(
    credentials,
    video_id: str,
    duration_seconds: int = VIDEO_DURATION_S,
) -> tuple:
    """
    Fetch viewerPercentage time-series from the YouTube Analytics API v2.

    Parameters
    ----------
    credentials   : google.oauth2.credentials.Credentials (OAuth 2.0) or None.
    video_id      : YouTube video ID.
    duration_seconds : Total video length in seconds.

    Returns
    -------
    (df, source) where:
        df      — pd.DataFrame(elapsed_seconds, viewer_percentage)
        source  — 'live'       : real viewerPercentage data from the API
                  'processing' : YouTube Analytics hasn't finished processing yet
                  'demo'       : no credentials or unrecoverable error
    """
    import youtube_api as _yt
    return _yt.fetch_retention_data(credentials, video_id, duration_seconds)


# ── Demo / synthetic data ─────────────────────────────────────────────────────

def make_demo_data(duration_seconds: int = VIDEO_DURATION_S) -> pd.DataFrame:
    """
    Generate a realistic synthetic audience retention curve.

    Models:
    - Sharp drop in the first ~10 s (click-through but no commitment)
    - Gradual exponential decay for the mid-section
    - A small engagement bump at 70 % through (common for music tracks)
    - Anomaly spike at 2:40–2:55 (higher-than-expected retention at end)
    """
    t = np.arange(0, duration_seconds + 1)

    # Base exponential decay: 100 % → ~35 % over the full video
    decay_rate = -math.log(0.35) / duration_seconds
    base = 100.0 * np.exp(-decay_rate * t)

    # Sharp early drop (first 12 s)
    early_drop = 18.0 * np.exp(-0.45 * t)
    base = base - early_drop
    base = np.clip(base, 0, 100)

    # Mid-video engagement bump (typical for music)
    bump_center = int(duration_seconds * 0.68)
    bump = 6.0 * np.exp(-0.003 * (t - bump_center) ** 2)
    base = base + bump

    # Anomaly zone: above-expected retention at 2:40–2:55
    # (strong hook / loop point at the end — a common music anomaly)
    anomaly_mask = (t >= ANOMALY_START_S) & (t <= ANOMALY_END_S)
    base[anomaly_mask] += np.linspace(4.0, 9.0, anomaly_mask.sum())

    # Light Gaussian smoothing to simulate real data
    base = gaussian_filter1d(base, sigma=1.8)
    base = np.clip(base, 0, 100)

    return pd.DataFrame({
        "elapsed_seconds":   t.astype(int),
        "viewer_percentage": np.round(base, 4),
    })


# ── Ridge plot builder ────────────────────────────────────────────────────────

def _seconds_to_mmss(seconds: float) -> str:
    m = int(seconds) // 60
    s = int(seconds) % 60
    return f"{m}:{s:02d}"


def build_ridge_plot(
    df: pd.DataFrame,
    video_id: str = "",
    output_path: str = DEFAULT_OUTPUT,
    duration_seconds: int = VIDEO_DURATION_S,
    n_segments: int = 7,
    data_source: str = "demo",
) -> str:
    """
    Render a Ridge Plot (Joyplot) of audience retention and save as PNG.

    Parameters
    ----------
    df              : DataFrame with columns elapsed_seconds, viewer_percentage.
    video_id        : Optional — shown in the chart title/footer.
    output_path     : Where to save the PNG.
    duration_seconds: Total video length in seconds (default 175 = 2:55).
    n_segments      : Number of horizontal ridge layers to stack.

    Returns the resolved output_path string.

    Ridge design
    ------------
    The time axis is divided into n_segments equal slices.  For each slice the
    local retention sub-series is expanded into a KDE (via scipy gaussian_filter1d)
    and plotted as a filled area.  The anomaly segment (2:40–2:55) is painted in
    the contrasting ANOMALY colour regardless of its position in the stack.
    """
    sns.set_theme(style="dark", rc={
        "axes.facecolor":   COLOR_PANEL,
        "figure.facecolor": COLOR_BG,
        "text.color":       COLOR_TEXT,
        "axes.labelcolor":  COLOR_TEXT,
        "xtick.color":      COLOR_TEXT,
        "ytick.color":      COLOR_TEXT,
        "grid.color":       COLOR_GRID,
    })

    # ── Resample to integer seconds ──────────────────────────────────────────
    full_t   = np.arange(0, duration_seconds + 1)
    pct_vals = np.interp(
        full_t,
        df["elapsed_seconds"].values,
        df["viewer_percentage"].values,
    )
    # Light smoothing on the full curve before segmenting
    pct_vals = gaussian_filter1d(pct_vals, sigma=1.5)

    # ── Build segments ───────────────────────────────────────────────────────
    seg_size = duration_seconds / n_segments
    segments: list[dict] = []
    for i in range(n_segments):
        t_start = int(round(i       * seg_size))
        t_end   = int(round((i + 1) * seg_size))
        is_anomaly = (t_start >= ANOMALY_START_S) or (
            t_start < ANOMALY_END_S and t_end > ANOMALY_START_S
        )
        mask = (full_t >= t_start) & (full_t <= t_end)
        segments.append({
            "t_start":    t_start,
            "t_end":      t_end,
            "t_vals":     full_t[mask],
            "pct":        pct_vals[mask],
            "is_anomaly": is_anomaly,
            "label":      f"{_seconds_to_mmss(t_start)}–{_seconds_to_mmss(t_end)}",
        })

    # ── Figure layout ────────────────────────────────────────────────────────
    RIDGE_HEIGHT = 1.35          # vertical space per ridge
    V_OFFSET     = 12.0          # vertical offset between ridge baselines

    fig_h = max(7, n_segments * RIDGE_HEIGHT + 2.5)
    fig, ax = plt.subplots(figsize=(13, fig_h), facecolor=COLOR_BG)
    ax.set_facecolor(COLOR_PANEL)

    y_baselines: list[float] = []
    all_pct_max = float(pct_vals.max()) + 5.0

    for idx, seg in enumerate(segments):
        baseline = idx * V_OFFSET
        y_baselines.append(baseline)
        t_arr = seg["t_vals"]
        p_arr = seg["pct"]

        if len(t_arr) < 2:
            continue

        # KDE-smooth the segment independently for sharper ridge detail
        p_smooth = gaussian_filter1d(p_arr, sigma=0.8)

        color  = COLOR_ANOMALY if seg["is_anomaly"] else COLOR_NORMAL
        alpha_fill = 0.75 if seg["is_anomaly"] else (0.45 + 0.04 * idx)
        alpha_line = 0.95 if seg["is_anomaly"] else 0.80

        # Scale the amplitude so it fits the ridge height
        scale = V_OFFSET * 0.9 / max(all_pct_max, 1)
        y_ridge = baseline + p_smooth * scale

        # Filled area
        ax.fill_between(
            t_arr, baseline, y_ridge,
            color=color, alpha=alpha_fill, zorder=n_segments + idx,
        )
        # Ridge spine line
        ax.plot(
            t_arr, y_ridge,
            color=color, linewidth=1.6, alpha=alpha_line,
            zorder=n_segments + idx + 1,
        )
        # Baseline rule
        ax.axhline(
            y=baseline, xmin=(t_arr[0] / duration_seconds),
            xmax=(t_arr[-1] / duration_seconds),
            color=COLOR_GRID, linewidth=0.6, zorder=n_segments + idx - 1,
        )

        # Segment label on the left
        ax.text(
            t_arr[0] - 2, baseline + 1.5,
            seg["label"],
            ha="right", va="bottom",
            color=color if seg["is_anomaly"] else "#aaaaaa",
            fontsize=8.5, fontweight="bold" if seg["is_anomaly"] else "normal",
            zorder=n_segments * 2,
        )

        # Annotate peak viewership within segment
        peak_idx = int(np.argmax(p_arr))
        ax.annotate(
            f"{p_arr[peak_idx]:.1f}%",
            xy=(t_arr[peak_idx], y_ridge[peak_idx]),
            xytext=(0, 5), textcoords="offset points",
            ha="center", fontsize=7.5,
            color=color, alpha=0.9,
            zorder=n_segments * 2 + 1,
        )

    # ── Anomaly vertical band (full height, behind ridges) ───────────────────
    ax.axvspan(
        ANOMALY_START_S, ANOMALY_END_S,
        ymin=0, ymax=1,
        color=COLOR_ANOMALY, alpha=0.08,
        zorder=1, linewidth=0,
    )
    # Anomaly boundary lines
    for x_mark in (ANOMALY_START_S, ANOMALY_END_S):
        ax.axvline(
            x=x_mark,
            color=COLOR_ANOMALY, linewidth=1.2,
            linestyle="--", alpha=0.55, zorder=2,
        )
    # Anomaly label at the top
    ax.text(
        (ANOMALY_START_S + ANOMALY_END_S) / 2,
        y_baselines[-1] + V_OFFSET * 0.78,
        "⚠ ANOMALY\n2:40 – 2:55",
        ha="center", va="bottom",
        color=COLOR_ANOMALY, fontsize=9, fontweight="bold",
        zorder=n_segments * 2 + 5,
    )

    # ── X-axis ticks: every 30 s, formatted as M:SS ──────────────────────────
    tick_positions = list(range(0, duration_seconds + 1, 30))
    if duration_seconds not in tick_positions:
        tick_positions.append(duration_seconds)
    ax.set_xticks(tick_positions)
    ax.set_xticklabels(
        [_seconds_to_mmss(t) for t in tick_positions],
        fontsize=9, color=COLOR_TEXT,
    )
    ax.xaxis.set_minor_locator(ticker.MultipleLocator(10))

    # ── Y-axis: hide numbers, label with viewer % concept ────────────────────
    ax.set_yticks([])
    ax.set_xlim(-18, duration_seconds + 6)
    ax.set_ylim(-V_OFFSET * 0.25, y_baselines[-1] + V_OFFSET * 1.4)

    ax.set_xlabel("Elapsed Time", fontsize=10, labelpad=8, color="#888")
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.tick_params(axis="x", length=3, color=COLOR_GRID)

    # ── Legend ───────────────────────────────────────────────────────────────
    legend_handles = [
        mpatches.Patch(color=COLOR_NORMAL,  alpha=0.7, label="Audience Retention"),
        mpatches.Patch(color=COLOR_ANOMALY, alpha=0.8, label="Anomaly Zone  2:40–2:55"),
    ]
    ax.legend(
        handles=legend_handles,
        loc="upper right", frameon=True,
        framealpha=0.25, edgecolor="#444",
        fontsize=9, labelcolor=COLOR_TEXT,
        facecolor=COLOR_BG,
    )

    # ── Titles ───────────────────────────────────────────────────────────────
    vid_label = f" — {video_id}" if video_id else ""
    fig.suptitle(
        f"Audience Retention  ·  Ridge Plot{vid_label}",
        fontsize=14, fontweight="bold",
        color=COLOR_TEXT, y=0.98,
    )
    ax.set_title(
        f"viewerPercentage density over {_seconds_to_mmss(duration_seconds)} duration  "
        f"·  anomaly marker: 2:40–2:55",
        fontsize=9, color="#888", pad=10,
    )

    # ── Data-source badge / overlay ──────────────────────────────────────────
    if data_source == "live":
        # Small "LIVE" pill in the top-left corner
        fig.text(
            0.01, 0.985,
            "● LIVE  —  youtubeAnalytics.v2",
            ha="left", va="top",
            fontsize=8, fontweight="bold",
            color="#00ff99",
            bbox=dict(
                boxstyle="round,pad=0.35",
                facecolor="#002211", edgecolor="#00cc88",
                linewidth=0.8, alpha=0.85,
            ),
        )
    elif data_source == "processing":
        # Semi-transparent dark overlay with "DATA PENDING" text
        _ax_pos = ax.get_position()
        overlay_ax = fig.add_axes([
            _ax_pos.x0, _ax_pos.y0,
            _ax_pos.width, _ax_pos.height,
        ])
        overlay_ax.set_facecolor("none")
        overlay_ax.patch.set_alpha(0)
        overlay_ax.set_xlim(0, 1)
        overlay_ax.set_ylim(0, 1)
        for spine in overlay_ax.spines.values():
            spine.set_visible(False)
        overlay_ax.set_xticks([])
        overlay_ax.set_yticks([])

        # Dark semi-transparent rectangle
        overlay_ax.add_patch(plt.Rectangle(
            (0, 0), 1, 1,
            transform=overlay_ax.transAxes,
            color="#0e0e1a", alpha=0.72,
            zorder=100,
        ))
        overlay_ax.text(
            0.5, 0.58,
            "⏳  DATA PENDING",
            ha="center", va="center",
            fontsize=22, fontweight="bold",
            color=COLOR_ANOMALY,
            transform=overlay_ax.transAxes,
            zorder=101,
        )
        overlay_ax.text(
            0.5, 0.44,
            "YouTube Analytics is still processing this video.\n"
            "Retention data is usually available within 48–72 hours of upload.",
            ha="center", va="center",
            fontsize=10, color="#bbbbbb",
            transform=overlay_ax.transAxes,
            zorder=101,
        )
        overlay_ax.text(
            0.5, 0.30,
            "Ridge structure shown uses synthetic reference data.",
            ha="center", va="center",
            fontsize=8.5, color="#888888",
            transform=overlay_ax.transAxes,
            zorder=101,
        )

    # ── Footer ───────────────────────────────────────────────────────────────
    src_label = {
        "live":       "Source: YouTube Analytics API v2  (viewerPercentage — live)",
        "processing": "Source: Synthetic reference  (YouTube Analytics still processing)",
        "demo":       "Source: Synthetic reference  (connect YouTube for live data)",
    }.get(data_source, "Source: Musical Anomaly Dashboard")
    fig.text(
        0.5, 0.01,
        f"{src_label}  ·  Musical Anomaly Dashboard",
        ha="center", fontsize=7.5, color="#555",
    )

    plt.tight_layout(rect=[0, 0.02, 1, 0.97])
    fig.savefig(output_path, dpi=300, bbox_inches="tight", facecolor=COLOR_BG)
    plt.close(fig)

    return output_path


# ── One-call orchestrator ─────────────────────────────────────────────────────

def generate_report(
    video_id:           str                    = "",
    viewer_percentages: Optional[list[float]]  = None,
    elapsed_seconds:    Optional[list[int]]    = None,
    credentials                                = None,
    output_path:        str                    = DEFAULT_OUTPUT,
    duration_seconds:   int                    = VIDEO_DURATION_S,
) -> tuple:
    """
    Full pipeline: data → ridge plot → saved PNG.

    Priority order for data source:
    1. viewer_percentages + elapsed_seconds  (explicit paste-in data)
    2. credentials → YouTube Analytics API v2 (live viewerPercentage)
    3. Synthetic demo data

    Returns
    -------
    (output_path, source) where source is 'live' | 'processing' | 'demo'.
    """
    if viewer_percentages is not None:
        if elapsed_seconds is None:
            elapsed_seconds = list(range(len(viewer_percentages)))
        df = pd.DataFrame({
            "elapsed_seconds":   elapsed_seconds,
            "viewer_percentage": viewer_percentages,
        })
        source = "live"   # user supplied real data explicitly
    else:
        df, source = fetch_retention_data(
            credentials, video_id, duration_seconds
        )

    out = build_ridge_plot(
        df,
        video_id=video_id,
        output_path=output_path,
        duration_seconds=duration_seconds,
        data_source=source,
    )
    return out, source
