"""
audit.py — Audit engine for the Musical Anomaly Dashboard.

Public API
----------
PIVOT_RANK_THRESHOLD : int   — Rank position above which a track is failing (10).
PIVOT_DAY_THRESHOLD  : int   — Days after upload before a pivot is eligible (14).
days_since()                 — UTC-safe age helper (returns whole days).
compute_success_components() — Returns R, P, S and their sub-rates as a dict.
run_audit()                  — Full pipeline: YouTube stats + rank → S=R/P → status.
"""

import math
from datetime import datetime, timezone

import youtube_api as yt

PIVOT_RANK_THRESHOLD: int = 10
PIVOT_DAY_THRESHOLD: int  = 14


# ──────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────

def days_since(date_str: str) -> int:
    """Return whole days elapsed between a UTC ISO-8601 timestamp and now.

    Handles both 'Z' suffix and '+00:00' offset.  Returns 0 on any parse error.
    """
    if not date_str:
        return 0
    try:
        dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
        dt = dt.replace(tzinfo=timezone.utc)
        return (datetime.now(timezone.utc) - dt).days
    except Exception:
        return 0


# ──────────────────────────────────────────────────────────────
# S = R / P  formula
# ──────────────────────────────────────────────────────────────

def compute_success_components(
    view_count: int,
    like_count: int,
    comment_count: int,
) -> dict:
    """Compute the S = R / P success score with full component breakdown.

    Formula
    -------
    like_rate    = likes  / views
    comment_rate = comments / views
    R            = (like_rate × 0.7) + (comment_rate × 0.3)   — retention proxy
    P            = log₁₀(views) / 7                            — normalised popularity
    S            = R / P                                       — higher is better

    Returns
    -------
    dict with keys: r, p, s, like_rate, comment_rate
        All values are rounded to 6 decimal places.
        All values are 0.0 when view_count == 0.
    """
    if view_count == 0:
        return {"r": 0.0, "p": 0.0, "s": 0.0, "like_rate": 0.0, "comment_rate": 0.0}

    like_rate    = like_count    / view_count
    comment_rate = comment_count / view_count

    R = (like_rate * 0.7) + (comment_rate * 0.3)
    P = math.log10(max(view_count, 1)) / 7.0
    S = round(R / P, 6) if P > 0 else 0.0

    return {
        "r":            round(R, 6),
        "p":            round(P, 6),
        "s":            S,
        "like_rate":    round(like_rate,    6),
        "comment_rate": round(comment_rate, 6),
    }


# ──────────────────────────────────────────────────────────────
# Full audit pipeline
# ──────────────────────────────────────────────────────────────

def run_audit(track: dict) -> dict | None:
    """Run a full audit for one tracked video.

    Steps
    -----
    1. Fetch live YouTube statistics (views, likes, comments) for the video ID.
    2. Search the target keyword to determine current rank (1-based, up to 20).
    3. Compute S = R / P with full component breakdown.
    4. Derive status: 'ranking' | 'monitoring' | 'needs_pivot'.

    Status rules
    ------------
    needs_pivot  — age >= PIVOT_DAY_THRESHOLD  AND  rank > PIVOT_RANK_THRESHOLD (or not found)
    ranking      — rank is known AND rank <= PIVOT_RANK_THRESHOLD
    monitoring   — everything else (too early to judge)

    Returns None if the video ID cannot be found on YouTube.
    """
    youtube      = yt.get_youtube_client()
    video_id     = track["track_youtube_id"]
    keyword      = track["keyword"]

    stats = yt.get_video_stats(youtube, video_id)
    if not stats:
        return None

    rank          = yt.get_keyword_rank(youtube, keyword, video_id, max_results=20)
    view_count    = stats["view_count"]
    like_count    = stats["like_count"]
    comment_count = stats["comment_count"]

    age           = days_since(track.get("added_at", ""))
    scores        = compute_success_components(view_count, like_count, comment_count)

    pivot_eligible = age >= PIVOT_DAY_THRESHOLD
    rank_failing   = rank is None or rank > PIVOT_RANK_THRESHOLD
    days_to_check  = max(0, PIVOT_DAY_THRESHOLD - age)

    if pivot_eligible and rank_failing:
        status = "needs_pivot"
    elif rank is not None and rank <= PIVOT_RANK_THRESHOLD:
        status = "ranking"
    else:
        status = "monitoring"

    return {
        # Raw YouTube stats
        "view_count":    view_count,
        "like_count":    like_count,
        "comment_count": comment_count,
        "rank":          rank,
        # S = R / P components
        "r":             scores["r"],
        "p":             scores["p"],
        "success_score": scores["s"],
        "like_rate":     scores["like_rate"],
        "comment_rate":  scores["comment_rate"],
        # DB-compatible legacy fields
        "retention_estimate": scores["like_rate"],
        "popularity_score":   round(view_count / 1_000_000, 6),
        # Timing
        "days_since_added": age,
        "days_to_check":    days_to_check,
        "pivot_eligible":   pivot_eligible,
        # Decision
        "status":       status,
        "rank_failing": rank_failing,
    }
