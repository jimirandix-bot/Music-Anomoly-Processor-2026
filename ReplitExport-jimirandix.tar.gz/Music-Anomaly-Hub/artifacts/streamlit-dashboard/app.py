import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timezone
import json
import os

import db
import youtube_api as yt
import audit as audit_engine
import llm
import exporter
import retention_viz
import oauth_manager

db.init_db()

st.set_page_config(
    page_title="Musical Anomaly Dashboard",
    page_icon="🎵",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.title("🎵 Musical Anomaly Dashboard")
st.caption("YouTube Content Gap Scanner · Metadata Architect · Audit Loop")

tab1, tab2, tab3 = st.tabs(["🔍 Gap Scanner", "🏗️ Metadata Architect", "📊 Audit Loop"])


# ─────────────────────────────────────────────
# SIDEBAR — YOUTUBE CHANNEL SYNC
# ─────────────────────────────────────────────
with st.sidebar:
    st.header("📡 Channel Sync")
    st.caption("jimirandix@gmail.com")
    st.divider()

    # ── Credential check ──────────────────────
    if not oauth_manager.credentials_available():
        st.error(
            "**Setup required:**\n\n"
            "Add these two Replit Secrets:\n"
            "- `GOOGLE_CLIENT_ID`\n"
            "- `GOOGLE_CLIENT_SECRET`\n\n"
            "Get them from **Google Cloud Console → APIs & Services → "
            "Credentials → OAuth 2.0 Client IDs** (type: Desktop app).\n\n"
            "Set the Authorised redirect URI to `http://localhost` and add "
            "`jimirandix@gmail.com` as a Test User."
        )
        st.stop()

    # ── Load existing credentials ─────────────
    _creds = oauth_manager.load_credentials()

    # ── OAuth state machine ───────────────────
    if _creds and _creds.valid:
        # ── CONNECTED ────────────────────────
        st.success("✅ Connected to YouTube")
        if st.button("🔌 Disconnect", use_container_width=True):
            oauth_manager.revoke()
            st.session_state.pop("yt_videos", None)
            st.session_state.pop("selected_video", None)
            st.rerun()

        st.divider()

        # ── Fetch & cache videos ─────────────
        if "yt_videos" not in st.session_state:
            try:
                with st.spinner("Fetching your latest uploads…"):
                    st.session_state["yt_videos"] = yt.fetch_my_activities(_creds, max_results=10)
            except Exception as _e:
                st.warning(f"Could not fetch videos: {_e}")
                st.session_state["yt_videos"] = []

        _videos = st.session_state.get("yt_videos", [])

        if st.button("🔄 Refresh", use_container_width=True):
            st.session_state.pop("yt_videos", None)
            st.rerun()

        st.subheader("Select Live Data Point")

        if not _videos:
            st.info("No uploads found on this channel.")
        else:
            _options = {
                f"{v['title']}  ({v['video_id']})": v
                for v in _videos
            }
            _prev = st.session_state.get("selected_video")
            _prev_label = None
            if _prev:
                _prev_label = next(
                    (k for k, v in _options.items() if v["video_id"] == _prev["video_id"]),
                    None,
                )
            _labels = list(_options.keys())
            _idx = _labels.index(_prev_label) if _prev_label in _labels else 0

            _chosen_label = st.selectbox(
                "Last 10 uploads",
                _labels,
                index=_idx,
                label_visibility="collapsed",
            )
            _chosen = _options[_chosen_label]

            # Store into session state — auto-fills Tab 2 + Tab 3
            st.session_state["selected_video"] = _chosen

            # Thumbnail preview
            if _chosen.get("thumbnail_url"):
                st.image(_chosen["thumbnail_url"], width="stretch")

            _pub = _chosen.get("published_at", "")[:10]
            st.caption(f"Published: {_pub}  ·  ID: `{_chosen['video_id']}`")

            st.markdown(
                f"[▶ Open on YouTube](https://youtube.com/watch?v={_chosen['video_id']})",
                unsafe_allow_html=False,
            )

            st.info(
                "Fields auto-filled:\n"
                "- 🏗️ Metadata Architect keyword\n"
                "- 📊 Audit Loop — Add Track form"
            )

    else:
        # ── NOT CONNECTED ─────────────────────
        st.info(
            "Connect your YouTube account to populate the "
            "**Select Live Data Point** dropdown with your last 10 uploads."
        )

        if not st.session_state.get("_oauth_flow_started"):
            if st.button("🔑 Connect YouTube Account", type="primary", use_container_width=True):
                st.session_state["_oauth_flow_started"] = True
                st.rerun()
        else:
            try:
                _auth_url = oauth_manager.get_auth_url()
            except RuntimeError as _e:
                st.error(str(_e))
                st.stop()

            st.markdown("**Step 1 — Open this link in your browser:**")
            st.code(_auth_url, language=None)

            st.markdown(
                "**Step 2 —** Authorise with `jimirandix@gmail.com`. "
                "You'll be redirected to `http://localhost` — the page will fail "
                "to load. **That's expected.**"
            )

            st.markdown(
                "**Step 3 —** Copy the full URL from your browser address bar "
                "and paste it below:"
            )

            _pasted = st.text_input(
                "Paste redirect URL here",
                placeholder="http://localhost/?code=4/0AX...",
                key="_oauth_redirect_paste",
            )

            if st.button("✅ Verify & Connect", type="primary", use_container_width=True):
                if not _pasted.strip():
                    st.warning("Paste the redirect URL first.")
                else:
                    try:
                        oauth_manager.exchange_url(_pasted.strip())
                        st.session_state.pop("_oauth_flow_started", None)
                        st.session_state.pop("_oauth_redirect_paste", None)
                        st.session_state.pop("yt_videos", None)
                        st.success("Connected! Reloading…")
                        st.rerun()
                    except Exception as _ex:
                        st.error(f"Connection failed: {_ex}")

            if st.button("✖ Cancel", use_container_width=True):
                st.session_state.pop("_oauth_flow_started", None)
                st.rerun()


# ─────────────────────────────────────────────
# TAB 1 — GAP SCANNER
# ─────────────────────────────────────────────
with tab1:
    st.header("Gap Scanner")
    st.markdown(
        "Scans YouTube for **'Music for…' / 'Songs for…'** keywords where the "
        "top results are **over 3 years old** — these are your Content Gaps."
    )

    col_left, col_right = st.columns([1, 2])

    with col_left:
        st.subheader("Controls")
        st.info(
            "A full scan covers hundreds of keyword combinations. "
            "Use **Quick Scan** for a fast sample of 30 keywords."
        )
        quick_mode = st.checkbox("Quick Scan (30 keywords)", value=True)

        if st.button("🚀 Run Gap Scan", type="primary", use_container_width=True):
            progress_bar = st.progress(0, text="Initialising scan…")
            status_text = st.empty()
            results_placeholder = st.empty()

            found = []

            import youtube_api as yt_inner
            import itertools

            if quick_mode:
                prefixes = yt_inner.MUSIC_PREFIXES[:3]
                seeds = yt_inner.SEED_KEYWORDS[:10]
            else:
                prefixes = yt_inner.MUSIC_PREFIXES
                seeds = yt_inner.SEED_KEYWORDS

            keywords = [f"{p} {s}" for p in prefixes for s in seeds]
            total = len(keywords)

            try:
                youtube = yt_inner.get_youtube_client()
            except ValueError as e:
                st.error(str(e))
                st.stop()

            for i, keyword in enumerate(keywords):
                pct = int((i / total) * 100)
                progress_bar.progress(pct, text=f"Scanning: {keyword}")
                status_text.text(f"{i+1}/{total} keywords checked — {len(found)} gaps found so far")

                try:
                    videos = yt_inner.search_videos_for_keyword(youtube, keyword, max_results=5)
                except Exception:
                    continue

                if not videos:
                    continue

                top = videos[0]
                avg_age = sum(v["age_days"] for v in videos) / len(videos)

                if avg_age >= yt_inner.STALE_DAYS_THRESHOLD:
                    gap_score = yt_inner.compute_gap_score(
                        top["age_days"], top["view_count"], len(videos)
                    )
                    anomaly = {
                        "keyword": keyword,
                        "search_volume_proxy": len(videos),
                        "top_video_age_days": top["age_days"],
                        "top_video_title": top["title"],
                        "top_video_id": top["video_id"],
                        "top_video_published": top["published"],
                        "top_video_views": top["view_count"],
                        "gap_score": gap_score,
                    }
                    anomaly_id = db.save_anomaly(**anomaly)
                    anomaly["id"] = anomaly_id
                    found.append(anomaly)

            progress_bar.progress(100, text="Scan complete!")
            status_text.text(f"✅ Scan finished — {len(found)} content gaps found")

            if found:
                st.session_state["last_scan"] = found
                st.success(f"Found **{len(found)} content gaps** — saved to database.")
            else:
                st.warning("No gaps found in this scan. Try unchecking Quick Scan for full coverage.")

    with col_right:
        st.subheader("Detected Anomalies")
        anomalies = db.get_anomalies()

        if not anomalies:
            st.info("No anomalies yet. Run a Gap Scan to populate this list.")
        else:
            df = pd.DataFrame(anomalies)
            df["age_years"] = (df["top_video_age_days"] / 365).round(1)
            df["views_k"] = (df["top_video_views"] / 1000).round(1)
            df["found_at"] = pd.to_datetime(df["found_at"]).dt.strftime("%Y-%m-%d %H:%M")

            st.metric("Total Gaps in DB", len(df))

            fig = px.scatter(
                df,
                x="top_video_age_days",
                y="gap_score",
                size="gap_score",
                color="gap_score",
                hover_name="keyword",
                hover_data={"top_video_title": True, "age_years": True, "views_k": True},
                labels={
                    "top_video_age_days": "Top Video Age (days)",
                    "gap_score": "Gap Score",
                },
                title="Content Gaps — Staleness vs Opportunity Score",
                color_continuous_scale="RdYlGn",
            )
            fig.update_layout(height=350, margin=dict(t=40, b=20))
            st.plotly_chart(fig)

            display_cols = ["keyword", "gap_score", "age_years", "views_k", "top_video_title", "found_at"]
            st.dataframe(
                df[display_cols].rename(columns={
                    "keyword": "Keyword",
                    "gap_score": "Gap Score",
                    "age_years": "Staleness (yrs)",
                    "views_k": "Top Video Views (K)",
                    "top_video_title": "Top Video Title",
                    "found_at": "Found At",
                }),
                use_container_width=True,
                hide_index=True,
            )

            st.subheader("⚡ Gap Alerts")
            top_gaps = df[df["gap_score"] >= 70].sort_values("gap_score", ascending=False)
            if not top_gaps.empty:
                for _, row in top_gaps.head(5).iterrows():
                    st.warning(
                        f"🚨 **HIGH GAP:** `{row['keyword']}` — Score: **{row['gap_score']}** | "
                        f"Top video is **{row['age_years']} years old** with {row['views_k']}K views"
                    )
            else:
                st.success("No critical gaps (score ≥ 70) yet. Run more scans.")


# ─────────────────────────────────────────────
# TAB 2 — METADATA ARCHITECT
# ─────────────────────────────────────────────
with tab2:
    st.header("Metadata Architect")
    st.markdown(
        "Select a Stale Gap and generate a full **2026 Utility Profile** — "
        "SEO Architecture, Production Parameters, and Pivot Strategy — ready to copy straight into YouTube."
    )

    # ── Auto-fill banner from sidebar video selection ──────────────────────
    _sv = st.session_state.get("selected_video")
    if _sv:
        _sv_kw = yt._keyword_from_title(_sv["title"])
        with st.container(border=True):
            _ba, _bb = st.columns([5, 1])
            _ba.markdown(
                f"📡 **Live Data Point selected:** {_sv['title']}  \n"
                f"Extracted keyword: **`{_sv_kw}`** · "
                f"[▶ Watch](https://youtube.com/watch?v={_sv['video_id']})"
            )
            if _bb.button("✖ Clear", key="clear_sv"):
                st.session_state.pop("selected_video", None)
                st.rerun()

        if st.button(
            f"🧠 Generate Utility Profile for "{_sv['title'][:55]}…"",
            type="primary",
            key="gen_from_yt",
        ):
            with st.spinner("Building 2026 profile from your uploaded video…"):
                try:
                    _sv_profile = llm.generate_utility_profile(
                        keyword=_sv_kw,
                        top_video_title=_sv["title"],
                        gap_score=0.0,
                    )
                    st.session_state["generated_profile"] = _sv_profile
                    st.session_state["profile_anomaly"] = {
                        "id": None,
                        "keyword": _sv_kw,
                        "top_video_title": _sv["title"],
                        "top_video_id": _sv["video_id"],
                        "top_video_age_days": 0,
                        "top_video_views": 0,
                        "gap_score": 0.0,
                    }
                except Exception as _e:
                    st.error(f"LLM error: {_e}")
        st.divider()

    anomalies = db.get_anomalies()

    if not anomalies:
        st.info("No anomalies yet. Run a Gap Scan first.")
    else:
        # ── Anomaly selector ──────────────────────────────────────
        keyword_options = {
            f"{a['keyword']}  |  Gap Score: {a['gap_score']}  |  {round(a['top_video_age_days']/365,1)} yrs stale": a
            for a in anomalies
        }
        selected_label = st.selectbox("Choose a Stale Gap to profile:", list(keyword_options.keys()))
        selected_anomaly = keyword_options[selected_label]

        info_c1, info_c2, info_c3 = st.columns(3)
        info_c1.metric("Gap Score", selected_anomaly["gap_score"])
        info_c2.metric("Top Video Age", f"{round(selected_anomaly['top_video_age_days']/365,1)} yrs")
        info_c3.metric("Top Video Views", f"{selected_anomaly['top_video_views']:,}")
        st.caption(
            f"Stale incumbent: [{selected_anomaly['top_video_title']}]"
            f"(https://youtube.com/watch?v={selected_anomaly['top_video_id']})"
        )

        if st.button("🧠 Generate Full Utility Profile", type="primary", use_container_width=True):
            with st.spinner("Building your 2026 SEO + Production + Pivot profile…"):
                try:
                    profile = llm.generate_utility_profile(
                        keyword=selected_anomaly["keyword"],
                        top_video_title=selected_anomaly.get("top_video_title", ""),
                        gap_score=selected_anomaly.get("gap_score", 0.0),
                    )
                    st.session_state["generated_profile"] = profile
                    st.session_state["profile_anomaly"] = selected_anomaly
                except Exception as e:
                    st.error(f"LLM error: {e}")

        st.divider()

        if "generated_profile" in st.session_state:
            profile = st.session_state["generated_profile"]
            anomaly = st.session_state["profile_anomaly"]
            seo = profile.get("seo", {})
            prod = profile.get("production", {})
            pivot = profile.get("pivot_strategy", {})

            # ── SECTION 1: SEO ARCHITECTURE ──────────────────────
            st.subheader("① SEO Architecture")
            st.caption("Copy these directly into your YouTube upload form.")

            seo_col1, seo_col2 = st.columns([3, 2])
            with seo_col1:
                primary_title = st.text_input(
                    "Primary Title (2026-optimised)",
                    value=seo.get("primary_title", ""),
                    help="Lead title for your upload. Max 70 chars for full display in search."
                )
                st.markdown("**Alt Titles — A/B Test these:**")
                alt_titles_raw = seo.get("alt_titles", [])
                if isinstance(alt_titles_raw, list):
                    for i, t in enumerate(alt_titles_raw):
                        st.text_input(f"Alt Title {i+1}", value=t, key=f"alt_{i}")
                    alt_titles_str = "\n".join(alt_titles_raw)
                else:
                    alt_titles_str = str(alt_titles_raw)
                    st.text_area("Alt Titles", value=alt_titles_str)

            with seo_col2:
                desc = st.text_area(
                    "Description Snippet",
                    value=seo.get("description_snippet", ""),
                    height=120,
                    help="2-sentence value hook — paste as first lines of your YouTube description."
                )

            tags_raw = seo.get("tags", [])
            if isinstance(tags_raw, list):
                tags_str = ", ".join(tags_raw)
            else:
                tags_str = str(tags_raw)
            tags_input = st.text_area(
                "Tags (10 high-intent)",
                value=tags_str,
                help="Paste directly into the YouTube tag field."
            )
            st.markdown(
                f"**Tag count:** {len([t for t in tags_str.split(',') if t.strip()])} tags  "
                f"| **Title length:** {len(primary_title)} chars"
            )

            st.divider()

            # ── SECTION 2: PRODUCTION PARAMETERS ─────────────────
            st.subheader("② Production Parameters")
            st.caption("Zero-spend tool prompts — ready to paste into Sonauto or AudioCraft.")

            p1, p2, p3, p4 = st.columns(4)
            bpm_val = p1.number_input("BPM", min_value=40, max_value=220,
                                      value=int(prod.get("bpm", 80)))
            key_val = p2.text_input("Key", value=prod.get("key", "C Major"))
            mood_val = p3.text_input("Mood", value=prod.get("mood", "Calm"))
            energy_val = p4.slider("Energy (1–10)", 1, 10,
                                   value=int(prod.get("energy", 5)))

            st.markdown("**Sonauto Prompt** *(Free vocal generation — tag-heavy format)*")
            sonauto = st.text_area(
                "Sonauto",
                value=prod.get("sonauto_prompt", ""),
                height=90,
                label_visibility="collapsed"
            )

            st.markdown("**AudioCraft / MusicGen Prompt** *(Local / open-source — technical parameters)*")
            audiocraft = st.text_area(
                "AudioCraft",
                value=prod.get("audiocraft_prompt", ""),
                height=90,
                label_visibility="collapsed"
            )

            st.divider()

            # ── SECTION 3: PIVOT STRATEGY ─────────────────────────
            st.subheader("③ Pivot Strategy")
            st.caption("Pre-built failure plan — baked in before you even upload.")

            piv1, piv2 = st.columns(2)
            with piv1:
                st.success(f"🎯 **Success Target:** {pivot.get('success_target', 'Rank #5 within 14 days')}")
                st.warning(f"✂️ **If Rank Fails:** {pivot.get('if_rank_fails', '—')}")
            with piv2:
                st.info(f"🖼️ **Thumbnail Tip:** {pivot.get('thumbnail_tip', '—')}")

            pivot_str = json.dumps(pivot)

            st.divider()

            # ── SAVE ─────────────────────────────────────────────
            notes_val = st.text_area("Additional Notes (optional)", value="", height=60)

            if st.button("💾 Save as Pending Project", type="primary", use_container_width=True):
                alt_titles_save = "\n".join(
                    seo.get("alt_titles", [])
                    if isinstance(seo.get("alt_titles"), list)
                    else [seo.get("alt_titles", "")]
                )
                project_id = db.save_project(
                    anomaly_id=anomaly["id"],
                    keyword=anomaly["keyword"],
                    seo_title=primary_title,
                    alt_titles=alt_titles_save,
                    description_snippet=desc,
                    bpm=bpm_val,
                    musical_key=key_val,
                    mood=mood_val,
                    energy=energy_val,
                    tags=tags_input,
                    sonauto_prompt=sonauto,
                    audiocraft_prompt=audiocraft,
                    pivot_strategy=pivot_str,
                    notes=notes_val,
                )
                st.success(f"✅ Saved as Pending Project #{project_id}")
                st.balloons()
        else:
            st.info("Select a Stale Gap above and click **Generate Full Utility Profile** to begin.")

        st.divider()

        # ── PENDING PROJECTS LIST ─────────────────────────────────
        st.subheader("📋 Pending Projects")
        projects = db.get_projects()
        if not projects:
            st.info("No projects saved yet.")
        else:
            status_colors = {"pending": "🟡", "in_progress": "🔵", "done": "🟢", "abandoned": "🔴"}
            for row in projects:
                s_icon = status_colors.get(row.get("status", "pending"), "⚪")
                label = row.get("seo_title") or row.get("keyword", "Untitled")
                with st.expander(f"{s_icon} {label}"):
                    mc1, mc2, mc3, mc4 = st.columns(4)
                    mc1.metric("BPM", row.get("bpm") or "—")
                    mc2.metric("Key", row.get("musical_key") or "—")
                    mc3.metric("Mood", row.get("mood") or "—")
                    mc4.metric("Energy", row.get("energy") or "—")

                    if row.get("description_snippet"):
                        st.markdown(f"**Description Hook:** {row['description_snippet']}")
                    if row.get("alt_titles"):
                        st.markdown("**Alt Titles:**")
                        for t in row["alt_titles"].split("\n"):
                            if t.strip():
                                st.markdown(f"- {t.strip()}")
                    if row.get("tags"):
                        st.markdown(f"**Tags:** `{row['tags']}`")
                    if row.get("sonauto_prompt"):
                        st.code(row["sonauto_prompt"], language=None)
                    if row.get("audiocraft_prompt"):
                        st.code(row["audiocraft_prompt"], language=None)
                    if row.get("pivot_strategy"):
                        try:
                            piv = json.loads(row["pivot_strategy"])
                            st.markdown(f"**If rank fails:** {piv.get('if_rank_fails', '—')}")
                            st.markdown(f"**Thumbnail tip:** {piv.get('thumbnail_tip', '—')}")
                        except Exception:
                            pass
                    if row.get("notes"):
                        st.markdown(f"**Notes:** {row['notes']}")

                    new_status = st.selectbox(
                        "Status",
                        ["pending", "in_progress", "done", "abandoned"],
                        index=["pending", "in_progress", "done", "abandoned"].index(
                            row.get("status", "pending")
                        ),
                        key=f"status_{row['id']}",
                    )
                    dl_col, upd_col = st.columns([1, 1])
                    with upd_col:
                        if st.button("Update Status", key=f"update_{row['id']}"):
                            db.update_project_status(row["id"], new_status)
                            st.rerun()
                    with dl_col:
                        project_full = db.get_project_by_id(row["id"])
                        if project_full:
                            bundle = exporter.generate_youtube_bundle(project_full)
                            filename = exporter.safe_filename(project_full.get("keyword", "project"))
                            st.download_button(
                                label="⬇️ Export Bundle (.txt)",
                                data=bundle.encode("utf-8"),
                                file_name=filename,
                                mime="text/plain",
                                key=f"dl_{row['id']}",
                            )


# ─────────────────────────────────────────────
# Shared helper — render a 5-field pivot card
# ─────────────────────────────────────────────
def _render_pivot_card(pivot: dict) -> None:
    """Display the five Metadata Pivot fields in a consistent, styled card."""
    # ① Title
    new_title = pivot.get("new_title", "—")
    st.markdown(
        f"<div style='background:#1a1a2e;border-left:4px solid #00cc88;"
        f"padding:8px 12px;border-radius:4px;margin-bottom:6px'>"
        f"<span style='color:#aaa;font-size:11px;text-transform:uppercase'>"
        f"New Title</span><br>"
        f"<span style='color:#f0f0f0;font-size:15px;font-weight:600'>"
        f"{new_title}</span></div>",
        unsafe_allow_html=True,
    )
    # ② Tags
    tags_raw = pivot.get("new_tags", [])
    tags_str = ", ".join(tags_raw) if isinstance(tags_raw, list) else str(tags_raw)
    st.markdown(
        f"<div style='background:#1a1a2e;border-left:4px solid #7c83fd;"
        f"padding:8px 12px;border-radius:4px;margin-bottom:6px'>"
        f"<span style='color:#aaa;font-size:11px;text-transform:uppercase'>"
        f"New Tags</span><br>"
        f"<span style='color:#d0d0ff;font-size:13px'>{tags_str}</span></div>",
        unsafe_allow_html=True,
    )
    # ③ Reason
    reason = pivot.get("pivot_reason", "—")
    st.markdown(
        f"<div style='background:#1a1a2e;border-left:4px solid #ffd166;"
        f"padding:8px 12px;border-radius:4px;margin-bottom:6px'>"
        f"<span style='color:#aaa;font-size:11px;text-transform:uppercase'>"
        f"Why This Pivot</span><br>"
        f"<span style='color:#ffe599;font-size:13px'>{reason}</span></div>",
        unsafe_allow_html=True,
    )
    # ④ Audio Edit
    audio_edit = pivot.get("frontend_edit", "—")
    st.markdown(
        f"<div style='background:#1a1a2e;border-left:4px solid #ff6b6b;"
        f"padding:8px 12px;border-radius:4px;margin-bottom:6px'>"
        f"<span style='color:#aaa;font-size:11px;text-transform:uppercase'>"
        f"✂ Audio Edit</span><br>"
        f"<span style='color:#ffb3b3;font-size:13px'>{audio_edit}</span></div>",
        unsafe_allow_html=True,
    )
    # ⑤ Thumbnail Change
    thumbnail = pivot.get("thumbnail_change", "—")
    st.markdown(
        f"<div style='background:#1a1a2e;border-left:4px solid #a8dadc;"
        f"padding:8px 12px;border-radius:4px;margin-bottom:6px'>"
        f"<span style='color:#aaa;font-size:11px;text-transform:uppercase'>"
        f"🖼 Thumbnail Change</span><br>"
        f"<span style='color:#cceef0;font-size:13px'>{thumbnail}</span></div>",
        unsafe_allow_html=True,
    )


# ─────────────────────────────────────────────
# TAB 3 — AUDIT LOOP
# ─────────────────────────────────────────────
with tab3:
    st.header("Audit Loop")
    st.markdown(
        "Add your uploaded YouTube track IDs. The loop fetches live rank via the YouTube API, "
        "computes **S = R / P**, and unlocks **Trigger Pivot** once a track misses top 10 after 14 days."
    )

    col_add, col_tracks = st.columns([1, 2])

    # ── LEFT PANEL ────────────────────────────────────────────────────
    with col_add:
        st.subheader("Add Track")
        projects = db.get_projects()
        project_options = {"— None —": None}
        for p in projects:
            project_options[f"#{p['id']} — {p['seo_title'] or p['keyword']}"] = p["id"]

        # Pre-fill from sidebar "Select Live Data Point" if a video is selected
        _sv3 = st.session_state.get("selected_video")
        if _sv3:
            st.info(
                f"📡 Auto-filling from: **{_sv3['title'][:50]}**",
                icon=None,
            )
        yt_video_id   = st.text_input(
            "YouTube Video ID",
            value=_sv3["video_id"] if _sv3 else "",
            placeholder="e.g. dQw4w9WgXcQ",
        )
        track_title   = st.text_input(
            "Track Title",
            value=_sv3["title"] if _sv3 else "",
        )
        audit_keyword = st.text_input(
            "Target Keyword",
            value=yt._keyword_from_title(_sv3["title"]) if _sv3 else "",
            placeholder="e.g. Music for studying",
        )
        linked_project = st.selectbox(
            "Link to Pending Project (optional)", list(project_options.keys())
        )

        if st.button("➕ Add Track", type="primary", use_container_width=True):
            if not yt_video_id or not track_title or not audit_keyword:
                st.warning("Fill in Video ID, Title, and Target Keyword.")
            else:
                pid = project_options[linked_project]
                db.add_audit_track(yt_video_id, track_title, audit_keyword, pid)
                st.success(f"✅ **{track_title}** added to audit loop.")
                st.rerun()

        st.divider()
        st.subheader("Run Audit")
        st.caption(
            "Pings YouTube for each track's live stats and keyword rank, "
            "then recalculates S = R / P."
        )

        if st.button("🔄 Run Audit Loop Now", use_container_width=True):
            tracks = db.get_audit_tracks()
            if not tracks:
                st.warning("No tracks added yet.")
            else:
                prog = st.progress(0, text="Starting audit…")
                needs_pivot_list = []

                for i, track in enumerate(tracks):
                    prog.progress(
                        int(i / len(tracks) * 100),
                        text=f"Auditing: {track['track_title']}",
                    )
                    try:
                        result = audit_engine.run_audit(track)
                        if result:
                            db.update_audit_track(
                                track_id=track["id"],
                                rank=result["rank"],
                                view_count=result["view_count"],
                                like_count=result["like_count"],
                                comment_count=result["comment_count"],
                                retention_estimate=result["retention_estimate"],
                                popularity_score=result["popularity_score"],
                                success_score=result["success_score"],
                                status=result["status"],
                            )
                            if result["status"] == "needs_pivot":
                                needs_pivot_list.append(track["track_title"])
                    except Exception as e:
                        st.error(f"Error — {track['track_title']}: {e}")

                prog.progress(100, text="Audit complete!")
                if needs_pivot_list:
                    st.error(
                        f"⚠️ {len(needs_pivot_list)} track(s) need a Pivot: "
                        + ", ".join(needs_pivot_list)
                    )
                else:
                    st.success("All tracks checked — no pivots needed.")
                st.rerun()

        st.divider()

        # ── Formula reference with CSS tooltips ──────────────────────
        st.subheader("📐 S = R / P")
        st.latex(r"S = \frac{R}{P}")
        st.html("""
<style>
  .formula-row { display:flex; flex-direction:column; gap:6px; margin-top:8px; }
  .formula-var {
    position:relative; display:inline-block;
    background:#1e1e2e; border:1px solid #333;
    border-radius:6px; padding:7px 10px;
    font-family:monospace; font-size:13px; cursor:default;
  }
  .formula-var .sym { color:#00cc88; font-weight:700; font-size:15px; }
  .formula-var .eq  { color:#888; margin:0 4px; }
  .formula-var .def { color:#ccc; }
  .formula-var .tip {
    visibility:hidden; opacity:0;
    background:#2a2a3e; color:#eee;
    border:1px solid #555; border-radius:6px;
    font-size:12px; line-height:1.5;
    padding:8px 10px; white-space:pre-line;
    position:absolute; left:0; top:calc(100% + 6px);
    z-index:999; min-width:260px;
    transition:opacity .15s ease;
    pointer-events:none;
  }
  .formula-var:hover .tip { visibility:visible; opacity:1; }
</style>
<div class="formula-row">
  <div class="formula-var">
    <span class="sym">R</span>
    <span class="eq">=</span>
    <span class="def">(likes/views × 0.7) + (comments/views × 0.3)</span>
    <div class="tip">Retention proxy.
Weights: likes count 70%, comments 30%.
Higher R → stronger audience engagement signal.
Good threshold: R &gt; 0.005</div>
  </div>
  <div class="formula-var">
    <span class="sym">P</span>
    <span class="eq">=</span>
    <span class="def">log₁₀(views) / 7</span>
    <div class="tip">Popularity (normalised 0–1).
log₁₀ compresses viral outliers.
÷7 so a video with 10M views scores ≈1.0.
Low P means the video hasn't gained traction yet.</div>
  </div>
  <div class="formula-var">
    <span class="sym">S</span>
    <span class="eq">=</span>
    <span class="def">R ÷ P — organic performance score</span>
    <div class="tip">Success score.
S &gt; 0.001 → performing well.
S &lt; 0.001 at Day 14+ with Rank &gt; 10 → Pivot required.
A high S with a low rank means the content is engaging
but not yet discovered — metadata fix likely needed.</div>
  </div>
</div>
<p style="color:#666;font-size:11px;margin-top:10px">
  Hover each variable to see formula details.
  Pivot triggers: Rank &gt; 10 &amp; Day ≥ 14.
</p>
""")

    # ── RIGHT PANEL ───────────────────────────────────────────────────
    with col_tracks:
        st.subheader("Monitored Tracks")
        tracks = db.get_audit_tracks()

        if not tracks:
            st.info("No tracks yet. Add a YouTube Video ID on the left to begin.")
        else:
            STATUS_ICON = {
                "monitoring":  "🔵",
                "ranking":     "🟢",
                "needs_pivot": "🔴",
            }

            for track in tracks:
                # ── Live timing (computed from DB timestamp, not stored status) ──
                days_age  = audit_engine.days_since(track.get("added_at", ""))
                days_left = max(0, audit_engine.PIVOT_DAY_THRESHOLD - days_age)

                # ── Live eligibility (independent of stored status) ──────────────
                rank_val      = track.get("current_rank")
                rank_failing  = rank_val is None or rank_val > audit_engine.PIVOT_RANK_THRESHOLD
                pivot_eligible = days_age >= audit_engine.PIVOT_DAY_THRESHOLD
                needs_pivot_now = pivot_eligible and rank_failing

                # Stored status only drives the expander icon; pivot logic uses live flags
                stored_status = track.get("status", "monitoring")
                icon = STATUS_ICON.get(
                    "needs_pivot" if needs_pivot_now else stored_status, "⚪"
                )

                with st.expander(
                    f"{icon} **{track['track_title']}** — `{track['keyword']}`",
                    expanded=needs_pivot_now,
                ):
                    # ── 4-metric row ─────────────────────────────────────────────
                    views    = track.get("view_count")    or 0
                    likes    = track.get("like_count")    or 0
                    comments = track.get("comment_count") or 0
                    rank_disp = f"#{rank_val}" if rank_val else "Not found"

                    c1, c2, c3, c4 = st.columns(4)
                    c1.metric(
                        "Rank", rank_disp,
                        delta="Top 10 ✓" if rank_val and rank_val <= 10 else "Outside Top 10",
                        delta_color="normal" if rank_val and rank_val <= 10 else "inverse",
                    )
                    c2.metric("Views",    f"{views:,}")
                    c3.metric("Likes",    f"{likes:,}")
                    c4.metric("Comments", f"{comments:,}")

                    # ── S = R / P breakdown (all three from same computation) ─────
                    scores = audit_engine.compute_success_components(views, likes, comments)
                    s_score = scores["s"]   # canonical value — consistent with R and P

                    sc1, sc2, sc3 = st.columns(3)
                    sc1.metric(
                        "R  (Retention)", f"{scores['r']:.5f}",
                        help="(likes/views × 0.7) + (comments/views × 0.3)  —  engagement signal",
                    )
                    sc2.metric(
                        "P  (Popularity)", f"{scores['p']:.5f}",
                        help="log₁₀(views) / 7  —  normalised traction (1.0 = 10M views)",
                    )
                    sc3.metric(
                        "S = R / P", f"{s_score:.5f}",
                        delta="performing" if s_score > 0.001 else "low",
                        delta_color="normal" if s_score > 0.001 else "inverse",
                        help="Success score. Above 0.001 is healthy. Below 0.001 at Day 14+ triggers pivot.",
                    )

                    # ── Day-14 countdown ──────────────────────────────────────────
                    if pivot_eligible:
                        st.markdown(
                            "<span style='color:#ff6b6b;font-weight:600'>"
                            f"🔓 Day {days_age} — Pivot window open"
                            "</span>",
                            unsafe_allow_html=True,
                        )
                    else:
                        st.progress(
                            days_age / audit_engine.PIVOT_DAY_THRESHOLD,
                            text=f"Day {days_age} / {audit_engine.PIVOT_DAY_THRESHOLD} "
                                 f"— Pivot unlocks in {days_left} day{'s' if days_left != 1 else ''}",
                        )

                    yt_url = f"https://youtube.com/watch?v={track['track_youtube_id']}"
                    st.markdown(f"[▶ Watch on YouTube]({yt_url})")
                    if track.get("last_checked"):
                        st.caption(f"Last audited: {track['last_checked'][:16]}")

                    # ── Dual-axis history chart ───────────────────────────────────
                    history = db.get_audit_history(track["id"])
                    if len(history) > 1:
                        hist_df = pd.DataFrame(history)
                        hist_df["checked_at"] = pd.to_datetime(hist_df["checked_at"])

                        fig_h = go.Figure()
                        fig_h.add_trace(go.Scatter(
                            x=hist_df["checked_at"],
                            y=hist_df["success_score"],
                            mode="lines+markers",
                            name="S = R/P",
                            line=dict(color="#00cc88", width=2),
                            yaxis="y1",
                        ))
                        if hist_df["rank"].notna().any():
                            fig_h.add_trace(go.Scatter(
                                x=hist_df["checked_at"],
                                y=hist_df["rank"],
                                mode="lines+markers",
                                name="Rank",
                                line=dict(color="#ff6b6b", width=2, dash="dot"),
                                yaxis="y2",
                            ))
                        fig_h.update_layout(
                            height=230,
                            margin=dict(t=24, b=10, l=10, r=10),
                            legend=dict(orientation="h", y=1.18),
                            paper_bgcolor="rgba(0,0,0,0)",
                            plot_bgcolor="rgba(0,0,0,0)",
                            yaxis=dict(
                                title="S score",
                                title_font=dict(color="#00cc88"),
                                tickfont=dict(color="#00cc88"),
                                side="left",
                                showgrid=True,
                                gridcolor="#2a2a2a",
                            ),
                            yaxis2=dict(
                                title="Rank",
                                title_font=dict(color="#ff6b6b"),
                                tickfont=dict(color="#ff6b6b"),
                                side="right",
                                overlaying="y",
                                autorange="reversed",  # #1 is highest visual point
                                showgrid=False,
                            ),
                        )
                        st.plotly_chart(fig_h)

                    st.divider()

                    # ── PIVOT ZONE ────────────────────────────────────────────────
                    # Gate: computed live from days_age + rank_val, not stored status
                    if not pivot_eligible and rank_failing:
                        st.warning(
                            f"⏳ Rank is outside top {audit_engine.PIVOT_RANK_THRESHOLD} "
                            f"— Pivot button unlocks on **Day {audit_engine.PIVOT_DAY_THRESHOLD}** "
                            f"({days_left} day{'s' if days_left != 1 else ''} away)."
                        )

                    if needs_pivot_now:
                        st.error(
                            f"🚨 **Pivot Required** — {rank_disp} after Day {days_age}.  "
                            f"S = {s_score:.5f}"
                        )

                        # Saved pivot (if exists)
                        if track.get("pivot_suggestion"):
                            try:
                                saved_pivot = json.loads(track["pivot_suggestion"])
                                st.markdown("**Saved Pivot Plan:**")
                                _render_pivot_card(saved_pivot)
                            except Exception:
                                pass

                        # Trigger Pivot button — always visible when needs_pivot_now
                        if st.button(
                            "🔁 Trigger Pivot",
                            key=f"pivot_{track['id']}",
                            type="primary",
                            use_container_width=True,
                        ):
                            with st.spinner("Generating AI Metadata Pivot…"):
                                try:
                                    # Pull pivot_strategy from linked project
                                    pivot_ctx = ""
                                    if track.get("project_id"):
                                        proj = db.get_project_by_id(track["project_id"])
                                        if proj:
                                            pivot_ctx = proj.get("pivot_strategy", "") or ""

                                    pivot = llm.generate_pivot(
                                        track_title=track["track_title"],
                                        keyword=track["keyword"],
                                        rank=rank_val,
                                        days_since_added=days_age,
                                        view_count=views,
                                        success_score=s_score,
                                        r_score=scores["r"],
                                        p_score=scores["p"],
                                        pivot_strategy_context=pivot_ctx,
                                    )
                                    db.save_pivot(track["id"], json.dumps(pivot))
                                    st.success("✅ Pivot generated and saved!")
                                    _render_pivot_card(pivot)
                                    st.rerun()
                                except Exception as e:
                                    st.error(f"Pivot generation failed: {e}")

    # ─────────────────────────────────────────────────────────────────
    # ANOMALY AUDIT PANEL — RETENTION RIDGE LANDSCAPE
    # ─────────────────────────────────────────────────────────────────
    st.divider()

    # ── Track selector ────────────────────────────────────────────────
    audit_tracks_all = db.get_audit_tracks()
    DEMO_LABEL = "Demo — STUDY_01 (synthetic)"

    track_map: dict[str, dict | None] = {DEMO_LABEL: None}
    for idx, t in enumerate(audit_tracks_all, start=1):
        label = f"Data Point {idx} — {t['track_title']} ({t['track_youtube_id']})"
        track_map[label] = t

    selected_label = st.selectbox(
        "Select track to audit",
        list(track_map.keys()),
        key="audit_panel_track",
        label_visibility="collapsed",
    )
    selected_track = track_map[selected_label]
    is_demo        = selected_track is None
    data_point_n   = list(track_map.keys()).index(selected_label)  # 0 = demo

    # ── Resolve metrics from track or demo defaults ───────────────────
    if is_demo:
        _video_id   = "STUDY_01"
        _rank_val   = 5
        _rank_disp  = "#5"
        _rank_delta = "NEW"
        _views      = 124
        _views_disp = "124"
        _views_delta = "+12%"
        _s_raw      = 0.89
        _s_disp     = "0.89"
        _s_delta    = "Stable"
        # AVD: mean of demo retention curve as a percentage
        _demo_df    = retention_viz.make_demo_data(retention_viz.VIDEO_DURATION_S)
        _avd_val    = round(_demo_df["viewer_percentage"].mean(), 1)
        _avd_disp   = f"{_avd_val}%"
        _avd_delta  = "High"
        _duration   = retention_viz.VIDEO_DURATION_S
    else:
        _video_id    = selected_track["track_youtube_id"]
        _rank_val    = selected_track.get("current_rank")
        _rank_disp   = f"#{_rank_val}" if _rank_val else "—"
        _rank_delta  = "Top 10 ✓" if _rank_val and _rank_val <= 10 else "Outside Top 10"
        _views       = selected_track.get("view_count") or 0
        _views_disp  = f"{_views:,}"
        _views_delta = None
        _likes       = selected_track.get("like_count") or 0
        _comments    = selected_track.get("comment_count") or 0
        _sc          = audit_engine.compute_success_components(_views, _likes, _comments)
        _s_raw       = _sc["s"]
        _s_disp      = f"{_s_raw:.4f}"
        _s_delta     = "Stable" if _s_raw > 0.001 else "Low"
        # AVD proxy: retention component R expressed as a % of video engagement
        _avd_val     = round(_sc["r"] * 100, 1)
        _avd_disp    = f"{_avd_val}%"
        _avd_delta   = "High" if _avd_val > 1.5 else ("Mid" if _avd_val > 0.5 else "Low")
        _duration    = retention_viz.VIDEO_DURATION_S

    # ── Panel header ──────────────────────────────────────────────────
    dp_label = "DEMO" if is_demo else f"DATA POINT {data_point_n}"
    st.header(f"📊 ANOMALY AUDIT: {dp_label}")

    # ── 4-metric row ──────────────────────────────────────────────────
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Rank",    _rank_disp,  _rank_delta)
    col2.metric("Views",   _views_disp, _views_delta)
    col3.metric("AVD",     _avd_disp,   _avd_delta)
    col4.metric("S-Score", _s_disp,     _s_delta)

    # ── Optional: paste custom viewerPercentage data ──────────────────
    with st.expander("⚙ Custom viewerPercentage data (optional)", expanded=False):
        st.caption(
            "Paste a flat JSON array `[100, 87.3, 82.1, ...]` (one value per second) "
            "or paired `[[elapsed_s, pct], ...]`. Leave blank to use synthetic demo data."
        )
        pasted_raw = st.text_area(
            "viewerPercentage JSON",
            height=90,
            placeholder="[100, 95.2, 90.1, 84.7, ...]",
            key="audit_panel_json",
        )
        custom_duration = st.number_input(
            "Video duration (seconds)",
            min_value=10, max_value=3600,
            value=_duration, step=5,
            key="audit_panel_duration",
        )

    # Parse custom data if provided
    _parsed_pct: list[float] | None = None
    _parsed_elapsed: list[int] | None = None
    if pasted_raw.strip():
        try:
            raw_json = json.loads(pasted_raw.strip())
            if raw_json and isinstance(raw_json[0], (int, float)):
                _parsed_pct = [float(v) for v in raw_json]
            elif raw_json and isinstance(raw_json[0], (list, tuple)):
                _parsed_elapsed = [int(p[0]) for p in raw_json]
                _parsed_pct     = [float(p[1]) for p in raw_json]
        except Exception:
            st.warning("Could not parse JSON — using demo data instead.")

    # ── Ridge landscape section ───────────────────────────────────────
    st.subheader("⛰️ RETENTION RIDGE LANDSCAPE")
    st.caption(
        "Ridge Plot (Joyplot) of `viewerPercentage` density over the full video duration.  "
        "**Anomaly Marker 2:40–2:55** shown in contrasting orange."
    )

    # Live OAuth credentials forwarded to the Analytics API
    _live_creds = oauth_manager.load_credentials()

    _btn_label = (
        "📡 Generate Live Retention Report"
        if _live_creds and not _parsed_pct
        else "Generate Anomaly Report"
    )
    if st.button(_btn_label, type="primary", use_container_width=True,
                 key="audit_panel_generate"):
        with st.spinner("Fetching retention data & rendering ridge plot…"):
            try:
                _path, _source = retention_viz.generate_report(
                    video_id=_video_id,
                    viewer_percentages=_parsed_pct,
                    elapsed_seconds=_parsed_elapsed,
                    credentials=_live_creds,
                    output_path=retention_viz.DEFAULT_OUTPUT,
                    duration_seconds=int(custom_duration),
                )
                st.session_state["audit_panel_rendered"] = True
                st.session_state["audit_panel_source"]  = _source
            except Exception as e:
                st.error(f"Render error: {e}")
                st.session_state["audit_panel_rendered"] = False

    if st.session_state.get("audit_panel_rendered") and \
            os.path.exists(retention_viz.DEFAULT_OUTPUT):

        # Data-source badge above the image
        _src = st.session_state.get("audit_panel_source", "demo")
        if _src == "live":
            st.success("📡 **Live data** — viewerPercentage from YouTube Analytics API v2")
        elif _src == "processing":
            st.warning(
                "⏳ **Data Pending** — YouTube Analytics is still processing this video "
                "(typically 48–72 h after upload). Ridge structure uses synthetic reference data."
            )
        else:
            st.info("🔬 **Demo data** — Connect YouTube in the sidebar for live retention curves.")

        st.image(
            retention_viz.DEFAULT_OUTPUT,
            caption=f"Retention Density — {retention_viz._seconds_to_mmss(_duration)} Build",
            width="stretch",
        )
        with open(retention_viz.DEFAULT_OUTPUT, "rb") as _f:
            st.download_button(
                label="⬇ Download anomaly_retention_report.png",
                data=_f.read(),
                file_name="anomaly_retention_report.png",
                mime="image/png",
                key="audit_panel_download",
            )
