"""
oauth_manager.py — Persistent OAuth 2.0 manager for YouTube Data API.

Flow (headless / server-compatible)
-------------------------------------
1. User clicks "Connect" in the Streamlit sidebar.
2. We generate an auth URL and display it.
3. User opens the URL in any browser, authorises, and is redirected to
   http://localhost?code=...  (page fails to load — that is expected).
4. User copies the full redirect URL from their browser address bar and
   pastes it into the sidebar text input.
5. We parse the code, exchange it for tokens, and write token.json.
6. On every subsequent app startup, load_credentials() reads token.json
   and auto-refreshes using the refresh_token — no re-login needed.

Secrets required (set via Replit Secrets)
------------------------------------------
  GOOGLE_CLIENT_ID      — from Google Cloud Console → OAuth 2.0 Credentials
  GOOGLE_CLIENT_SECRET  — from Google Cloud Console → OAuth 2.0 Credentials

Important: In Google Cloud Console, set the Authorised redirect URI to
  http://localhost
and add the account email as a Test User (while the app is in "Testing" mode).
"""

from __future__ import annotations

import os
from urllib.parse import urlparse, parse_qs

from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request

TOKEN_PATH = os.path.join(os.path.dirname(__file__), "token.json")

SCOPES = [
    "https://www.googleapis.com/auth/youtube.readonly",
    "https://www.googleapis.com/auth/yt-analytics.readonly",
]

# Redirect URI registered in Google Cloud Console
REDIRECT_URI = "http://localhost"


# ──────────────────────────────────────────────────────────────────────────────
# Internal helpers
# ──────────────────────────────────────────────────────────────────────────────

def _client_config() -> dict | None:
    """Build the OAuth client config dict from environment secrets."""
    client_id     = os.environ.get("GOOGLE_CLIENT_ID", "").strip()
    client_secret = os.environ.get("GOOGLE_CLIENT_SECRET", "").strip()
    if not client_id or not client_secret:
        return None
    return {
        "installed": {
            "client_id":     client_id,
            "client_secret": client_secret,
            "auth_uri":      "https://accounts.google.com/o/oauth2/auth",
            "token_uri":     "https://oauth2.googleapis.com/token",
            "redirect_uris": [REDIRECT_URI],
        }
    }


def _save(creds: Credentials) -> None:
    with open(TOKEN_PATH, "w") as f:
        f.write(creds.to_json())


# ──────────────────────────────────────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────────────────────────────────────

def credentials_available() -> bool:
    """Return True if GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET are set."""
    return bool(
        os.environ.get("GOOGLE_CLIENT_ID") and
        os.environ.get("GOOGLE_CLIENT_SECRET")
    )


def load_credentials() -> Credentials | None:
    """
    Load credentials from token.json.

    If the access token is expired but a refresh_token is present,
    the token is refreshed automatically and the updated token is saved.
    Returns None if token.json doesn't exist or credentials are invalid.
    """
    if not os.path.exists(TOKEN_PATH):
        return None
    try:
        creds = Credentials.from_authorized_user_file(TOKEN_PATH, SCOPES)
        if creds.expired and creds.refresh_token:
            creds.refresh(Request())
            _save(creds)
        return creds if creds.valid else None
    except Exception:
        return None


def get_auth_url() -> str:
    """
    Generate and return the Google OAuth 2.0 authorization URL.

    Raises RuntimeError if GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET are missing.
    """
    config = _client_config()
    if not config:
        raise RuntimeError(
            "GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET are not set. "
            "Add them in Replit Secrets."
        )
    from google_auth_oauthlib.flow import Flow
    flow = Flow.from_client_config(config, scopes=SCOPES, redirect_uri=REDIRECT_URI)
    auth_url, _ = flow.authorization_url(
        access_type="offline",   # ensures a refresh_token is issued
        prompt="consent",        # forces consent screen so refresh_token is returned
        include_granted_scopes="true",
    )
    return auth_url


def exchange_url(redirect_response_url: str) -> Credentials:
    """
    Parse the auth code from the redirect URL the user pasted, exchange it
    for OAuth tokens, persist them to token.json, and return the credentials.

    The redirect URL looks like:
        http://localhost/?code=4/0AX...&scope=...

    Raises ValueError if no code is found in the URL.
    Raises RuntimeError on token exchange failure.
    """
    parsed = urlparse(redirect_response_url.strip())
    params = parse_qs(parsed.query)
    codes  = params.get("code", [])
    if not codes:
        raise ValueError(
            "Could not find 'code' in the pasted URL. "
            "Make sure you copied the full URL from your browser address bar."
        )
    return _exchange_code(codes[0].strip())


def _exchange_code(code: str) -> Credentials:
    config = _client_config()
    if not config:
        raise RuntimeError("OAuth client credentials are not configured.")
    try:
        from google_auth_oauthlib.flow import Flow
        flow = Flow.from_client_config(config, scopes=SCOPES, redirect_uri=REDIRECT_URI)
        flow.fetch_token(code=code)
        creds = flow.credentials
        _save(creds)
        return creds
    except Exception as e:
        raise RuntimeError(f"Token exchange failed: {e}") from e


def revoke() -> None:
    """Delete the stored token, forcing re-authentication on the next login."""
    if os.path.exists(TOKEN_PATH):
        os.remove(TOKEN_PATH)


def token_exists() -> bool:
    """Return True if token.json is present on disk (connected before)."""
    return os.path.exists(TOKEN_PATH)
