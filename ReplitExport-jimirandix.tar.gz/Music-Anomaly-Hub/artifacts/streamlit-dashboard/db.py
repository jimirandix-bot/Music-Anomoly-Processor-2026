import sqlite3
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "anomaly_dashboard.db")


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_conn()
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS anomalies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            keyword TEXT NOT NULL,
            search_volume_proxy INTEGER,
            top_video_age_days INTEGER,
            top_video_title TEXT,
            top_video_id TEXT,
            top_video_published TEXT,
            top_video_views INTEGER,
            gap_score REAL,
            found_at TEXT NOT NULL
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS pending_projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            anomaly_id INTEGER,
            keyword TEXT NOT NULL,
            seo_title TEXT,
            alt_titles TEXT,
            description_snippet TEXT,
            bpm INTEGER,
            musical_key TEXT,
            mood TEXT,
            energy INTEGER,
            tags TEXT,
            sonauto_prompt TEXT,
            audiocraft_prompt TEXT,
            pivot_strategy TEXT,
            notes TEXT,
            status TEXT DEFAULT 'pending',
            created_at TEXT NOT NULL,
            FOREIGN KEY (anomaly_id) REFERENCES anomalies(id)
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS audit_tracks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            track_youtube_id TEXT NOT NULL,
            track_title TEXT NOT NULL,
            keyword TEXT NOT NULL,
            project_id INTEGER,
            added_at TEXT NOT NULL,
            last_checked TEXT,
            current_rank INTEGER,
            view_count INTEGER,
            like_count INTEGER,
            comment_count INTEGER,
            retention_estimate REAL,
            popularity_score REAL,
            success_score REAL,
            status TEXT DEFAULT 'monitoring',
            pivot_suggestion TEXT,
            FOREIGN KEY (project_id) REFERENCES pending_projects(id)
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS audit_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            track_id INTEGER NOT NULL,
            checked_at TEXT NOT NULL,
            rank INTEGER,
            view_count INTEGER,
            success_score REAL,
            FOREIGN KEY (track_id) REFERENCES audit_tracks(id)
        )
    """)

    _migrate_columns(c)
    conn.commit()
    conn.close()


def _migrate_columns(c):
    existing = {row[1] for row in c.execute("PRAGMA table_info(pending_projects)").fetchall()}
    new_cols = {
        "alt_titles": "TEXT",
        "description_snippet": "TEXT",
        "musical_key": "TEXT",
        "energy": "INTEGER",
        "sonauto_prompt": "TEXT",
        "audiocraft_prompt": "TEXT",
        "pivot_strategy": "TEXT",
    }
    for col, col_type in new_cols.items():
        if col not in existing:
            c.execute(f"ALTER TABLE pending_projects ADD COLUMN {col} {col_type}")


def save_anomaly(keyword, search_volume_proxy, top_video_age_days,
                 top_video_title, top_video_id, top_video_published,
                 top_video_views, gap_score):
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        INSERT INTO anomalies
        (keyword, search_volume_proxy, top_video_age_days, top_video_title,
         top_video_id, top_video_published, top_video_views, gap_score, found_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (keyword, search_volume_proxy, top_video_age_days, top_video_title,
          top_video_id, top_video_published, top_video_views, gap_score,
          datetime.utcnow().isoformat()))
    anomaly_id = c.lastrowid
    conn.commit()
    conn.close()
    return anomaly_id


def get_anomalies():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM anomalies ORDER BY gap_score DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def save_project(anomaly_id, keyword, seo_title, alt_titles="",
                 description_snippet="", bpm=80, musical_key="", mood="",
                 energy=5, tags="", sonauto_prompt="", audiocraft_prompt="",
                 pivot_strategy="", notes=""):
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        INSERT INTO pending_projects
        (anomaly_id, keyword, seo_title, alt_titles, description_snippet,
         bpm, musical_key, mood, energy, tags,
         sonauto_prompt, audiocraft_prompt, pivot_strategy, notes, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (anomaly_id, keyword, seo_title, alt_titles, description_snippet,
          bpm, musical_key, mood, energy, tags,
          sonauto_prompt, audiocraft_prompt, pivot_strategy, notes,
          datetime.utcnow().isoformat()))
    project_id = c.lastrowid
    conn.commit()
    conn.close()
    return project_id


def get_projects():
    conn = get_conn()
    rows = conn.execute("""
        SELECT p.*, a.gap_score, a.top_video_age_days
        FROM pending_projects p
        LEFT JOIN anomalies a ON p.anomaly_id = a.id
        ORDER BY p.created_at DESC
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_project_by_id(project_id: int) -> dict | None:
    conn = get_conn()
    row = conn.execute("""
        SELECT p.*, a.gap_score, a.top_video_age_days
        FROM pending_projects p
        LEFT JOIN anomalies a ON p.anomaly_id = a.id
        WHERE p.id = ?
    """, (project_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def update_project_status(project_id, status):
    conn = get_conn()
    conn.execute("UPDATE pending_projects SET status=? WHERE id=?", (status, project_id))
    conn.commit()
    conn.close()


def add_audit_track(track_youtube_id, track_title, keyword, project_id=None):
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
        INSERT INTO audit_tracks
        (track_youtube_id, track_title, keyword, project_id, added_at)
        VALUES (?, ?, ?, ?, ?)
    """, (track_youtube_id, track_title, keyword, project_id,
          datetime.utcnow().isoformat()))
    track_id = c.lastrowid
    conn.commit()
    conn.close()
    return track_id


def get_audit_tracks():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM audit_tracks ORDER BY added_at DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def update_audit_track(track_id, rank, view_count, like_count, comment_count,
                       retention_estimate, popularity_score, success_score,
                       status, pivot_suggestion=None):
    conn = get_conn()
    now = datetime.utcnow().isoformat()
    conn.execute("""
        UPDATE audit_tracks SET
            last_checked=?, current_rank=?, view_count=?, like_count=?,
            comment_count=?, retention_estimate=?, popularity_score=?,
            success_score=?, status=?, pivot_suggestion=?
        WHERE id=?
    """, (now, rank, view_count, like_count, comment_count,
          retention_estimate, popularity_score, success_score, status,
          pivot_suggestion, track_id))
    conn.execute("""
        INSERT INTO audit_history (track_id, checked_at, rank, view_count, success_score)
        VALUES (?, ?, ?, ?, ?)
    """, (track_id, now, rank, view_count, success_score))
    conn.commit()
    conn.close()


def save_pivot(track_id, pivot_suggestion):
    conn = get_conn()
    conn.execute("UPDATE audit_tracks SET pivot_suggestion=? WHERE id=?",
                 (pivot_suggestion, track_id))
    conn.commit()
    conn.close()


def get_audit_history(track_id):
    conn = get_conn()
    rows = conn.execute("""
        SELECT * FROM audit_history WHERE track_id=? ORDER BY checked_at ASC
    """, (track_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]
