import os
import json
import re
from openai import OpenAI

_client = None


def get_client():
    global _client
    if _client is None:
        base_url = os.environ.get("AI_INTEGRATIONS_OPENAI_BASE_URL")
        api_key = os.environ.get("AI_INTEGRATIONS_OPENAI_API_KEY", "placeholder")
        if base_url:
            _client = OpenAI(base_url=base_url, api_key=api_key)
        else:
            _client = OpenAI(api_key=api_key)
    return _client


def _parse_json(text: str) -> dict:
    text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r'\{.*\}', text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group())
            except Exception:
                pass
    return {}


def generate_utility_profile(keyword: str, top_video_title: str = "", gap_score: float = 0.0) -> dict:
    client = get_client()

    prompt = f"""You are a Digital Arbitrage Strategist specialising in YouTube music content for 2026.

We have identified a "Stale Gap": the top YouTube results for "{keyword}" are 3+ years old (Gap Score: {gap_score}).
Top ranking video currently: "{top_video_title}"

Generate a full Utility Profile as a single JSON object. Use these EXACT keys:

{{
  "seo": {{
    "primary_title": "<2026-specific title, max 70 chars, e.g. '{keyword} 2026 - High Quality & Modern'>",
    "alt_titles": [
      "<Variation 1 — lead with benefit>",
      "<Variation 2 — lead with year/freshness>",
      "<Variation 3 — niche-specific long tail>"
    ],
    "description_snippet": "<Exactly 2 sentences. Sentence 1: state the specific problem this track solves. Sentence 2: mention 2026 relevance and a call to bookmark/subscribe.>",
    "tags": ["<tag1>","<tag2>","<tag3>","<tag4>","<tag5>","<tag6>","<tag7>","<tag8>","<tag9>","<tag10>"]
  }},
  "production": {{
    "bpm": <integer>,
    "key": "<e.g. C Major, A Minor>",
    "mood": "<single descriptor>",
    "energy": <integer 1-10>,
    "sonauto_prompt": "<Tag-heavy prompt for Sonauto. Format: [Genre: X] [Vocal: X or Instrumental] [Energy: X] [Tempo: X] [Theme: X] [Mood: X] [Instrument: X]>",
    "audiocraft_prompt": "<Technical AudioCraft/MusicGen prompt with genre, instruments, BPM, mix style, fidelity level>"
  }},
  "pivot_strategy": {{
    "success_target": "Rank #5 within 14 days",
    "if_rank_fails": "<One specific actionable edit, e.g. 'Trim intro by 15s — algorithm penalises slow hooks' or 'Switch thumbnail to high-contrast blue/gold palette to improve CTR'>",
    "thumbnail_tip": "<One specific thumbnail composition tip for this keyword niche>"
  }}
}}

Return ONLY valid JSON. No markdown fences. No explanation outside the JSON."""

    response = client.chat.completions.create(
        model="gpt-5-mini",
        max_completion_tokens=1024,
        messages=[{"role": "user", "content": prompt}],
    )
    text = response.choices[0].message.content.strip()
    parsed = _parse_json(text)

    if not parsed or "seo" not in parsed:
        return _fallback_profile(keyword)

    return parsed


def _fallback_profile(keyword: str) -> dict:
    return {
        "seo": {
            "primary_title": f"{keyword} 2026 — High Quality Background Music",
            "alt_titles": [
                f"Best {keyword} Music 2026 | Fresh & Modern",
                f"2026 {keyword} Playlist — No Ads, No Interruptions",
                f"{keyword} Music for Focus & Flow 2026",
            ],
            "description_snippet": (
                f"This track was created specifically for anyone needing {keyword} in 2026. "
                "Bookmark this video and subscribe for weekly fresh uploads."
            ),
            "tags": [keyword, f"{keyword} music", f"{keyword} 2026", "background music",
                     "focus music", "no copyright music", "royalty free", "instrumental",
                     "study music", "relaxing music"],
        },
        "production": {
            "bpm": 80,
            "key": "C Major",
            "mood": "Calm",
            "energy": 4,
            "sonauto_prompt": f"[Genre: Ambient] [Vocal: Instrumental] [Energy: Low] [Tempo: Slow] [Theme: Focus] [Mood: Calm] [Instrument: Piano, Strings]",
            "audiocraft_prompt": f"Calm ambient background music, soft piano and strings, 80bpm, clean mix, high fidelity, no vocals",
        },
        "pivot_strategy": {
            "success_target": "Rank #5 within 14 days",
            "if_rank_fails": "Trim intro by 15s — algorithm penalises slow hooks",
            "thumbnail_tip": "Use high-contrast text on a dark background with a single focal instrument image",
        },
    }


def generate_pivot(track_title: str, keyword: str, rank, days_since_added: int,
                   view_count: int, success_score: float,
                   r_score: float = 0.0, p_score: float = 0.0,
                   pivot_strategy_context: str = "") -> dict:
    client = get_client()
    rank_str = f"#{rank}" if rank else "not found in top 20"

    strategy_block = ""
    if pivot_strategy_context:
        try:
            import json as _json
            strat = _json.loads(pivot_strategy_context)
            strategy_block = f"""
Original planned pivot strategy (from upload planning):
  - If Rank Fails : {strat.get('if_rank_fails', '—')}
  - Thumbnail Tip : {strat.get('thumbnail_tip', '—')}

Use this as primary guidance. Override only if the live metrics suggest a better path.
"""
        except Exception:
            pass

    prompt = f"""You are a YouTube music content strategist performing a live Metadata Pivot.

TRACK PERFORMANCE DATA
  Track title     : "{track_title}"
  Target keyword  : "{keyword}"
  Current rank    : {rank_str}
  Days since upload: {days_since_added}
  View count      : {view_count:,}
  S = R / P       : {success_score:.6f}
  R (retention)   : {r_score:.6f}
  P (popularity)  : {p_score:.6f}
{strategy_block}
DIAGNOSIS
  R is {"low — weak engagement signals (likes/comments)" if r_score < 0.005 else "acceptable"}
  P is {"low — video hasn't gained traction yet" if p_score < 0.3 else "moderate to high"}
  Rank is {"critically failing — not in top 10" if (rank is None or rank > 10) else f"borderline at #{rank}"}

Generate a Metadata Pivot as a JSON object with EXACTLY these keys:
- "new_title": A revised 2026-SEO-optimised title (max 70 chars, include keyword naturally)
- "new_tags": Array of exactly 10 revised high-intent YouTube tags
- "pivot_reason": 2 sentences — what the data says and what this pivot targets
- "frontend_edit": One specific, timestamped audio edit (e.g. "Trim 0:00–0:18 intro — algorithm rewards hooks in first 10s")
- "thumbnail_change": One specific thumbnail composition change with colours/elements named
- "action": exactly one of "metadata_pivot", "frontend_edit", or "both"

Return ONLY valid JSON. No markdown. No explanation outside the JSON."""

    response = client.chat.completions.create(
        model="gpt-5-mini",
        max_completion_tokens=512,
        messages=[{"role": "user", "content": prompt}],
    )
    text = response.choices[0].message.content.strip()
    parsed = _parse_json(text)

    if not parsed:
        return {
            "new_title": f"[Revised] {track_title} 2026",
            "new_tags": [keyword, f"{keyword} 2026", "background music"],
            "pivot_reason": "Could not parse pivot suggestion.",
            "frontend_edit": "Review intro length — trim to under 5 seconds.",
            "thumbnail_change": "Switch to high-contrast blue/gold palette.",
            "action": "both",
        }

    if isinstance(parsed.get("new_tags"), str):
        parsed["new_tags"] = [t.strip() for t in parsed["new_tags"].split(",")]

    return parsed
