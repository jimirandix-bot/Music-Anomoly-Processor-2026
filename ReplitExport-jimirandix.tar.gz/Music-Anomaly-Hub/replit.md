# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.
Also contains a standalone Python Streamlit app (Musical Anomaly Dashboard) in `artifacts/streamlit-dashboard/`.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.

## Musical Anomaly Dashboard (Python / Streamlit)

A private YouTube content gap analysis tool located at `artifacts/streamlit-dashboard/`.

### Files
- `app.py` — Main Streamlit single-page dashboard (3 tabs)
- `db.py` — SQLite database layer (anomalies, pending_projects, audit_tracks, audit_history)
- `youtube_api.py` — YouTube Data API v3 integration (gap scanning, video stats, rank checking)
- `llm.py` — OpenAI LLM integration via Replit AI proxy (utility profile + pivot generation)
- `requirements.txt` — Python dependencies
- `.streamlit/config.toml` — Streamlit server config (port 5000)
- `anomaly_dashboard.db` — Local SQLite database (auto-created)

### Features
1. **Gap Scanner** — Scans YouTube for "Music for…/Songs for…" keywords where top results average >3 years old. Calculates a Gap Score and saves anomalies to SQLite. Alerts shown for scores ≥70.
2. **Metadata Architect** — Generates AI Utility Profiles (SEO title, BPM, mood, tags) per anomaly. Saves as Pending Projects with status tracking.
3. **Audit Loop** — Tracks YouTube video IDs, calculates `S = R/P` (Success = Retention/Popularity), flags tracks not ranking top-10 after 14 days, and triggers LLM-generated Metadata Pivots or Frontend Edit suggestions.

### Secrets Required
- `YOUTUBE_API_KEY` — YouTube Data API v3 key
- `AI_INTEGRATIONS_OPENAI_BASE_URL` — auto-set by Replit AI integration
- `AI_INTEGRATIONS_OPENAI_API_KEY` — auto-set by Replit AI integration

### Workflow
- Name: `Musical Anomaly Dashboard`
- Command: `cd artifacts/streamlit-dashboard && streamlit run app.py --server.port 5000`
- Port: 5000
