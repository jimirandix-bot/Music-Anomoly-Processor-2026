"use client";

import { Mail } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function VerifyEmailPage() {
  return (
    <main className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="max-w-md w-full text-center">
        <div className="size-20 rounded-full bg-gradient-to-br from-zinc-700 to-zinc-900 flex items-center justify-center mx-auto mb-6 shadow-lg shadow-zinc-900/50">
          <Mail className="size-10 text-zinc-300" />
        </div>
        <h1 className="text-2xl font-bold text-foreground mb-2">Check your email</h1>
        <p className="text-muted-foreground mb-6">
          A sign-in link has been sent to your email address. Click the link to complete your sign in.
        </p>
        <Link href="/">
          <Button variant="outline" className="border-zinc-700 text-zinc-300 hover:bg-zinc-800">
            Return to Home
          </Button>
        </Link>
      </div>
    </main>
  );
}
