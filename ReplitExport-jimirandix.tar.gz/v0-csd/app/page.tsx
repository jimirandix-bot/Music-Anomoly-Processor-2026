"use client";

import { useState, useEffect } from "react";
import { Plus, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScanModal } from "@/components/scan-modal";
import { DiagnosticCard } from "@/components/diagnostic-card";
import { ScanHistory } from "@/components/scan-history";
import { SettingsModal } from "@/components/settings-modal";
import { UserMenu } from "@/components/user-menu";
import { CategorySelector, type DiagnosticCategory } from "@/components/category-selector";
import { OBDDashboard } from "@/components/obd-dashboard";
import { ProUpsellModal } from "@/components/pro-upsell-modal";
import { ChromeLogo } from "@/components/chrome-logo";
import { type DiagnosticResult } from "@/lib/acoustics";

const STORAGE_KEY = "acoustic-diagnostics-history";

export default function CarSoundDiagnostics() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isProModalOpen, setIsProModalOpen] = useState(false);
  const [history, setHistory] = useState<DiagnosticResult[]>([]);
  const [selectedResult, setSelectedResult] = useState<DiagnosticResult | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<DiagnosticCategory>("engine");
  const [isOBDActive, setIsOBDActive] = useState(false);

  // Load history from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as DiagnosticResult[];
        setHistory(parsed);
        if (parsed.length > 0) {
          setSelectedResult(parsed[0]);
        }
      }
    } catch (error) {
      console.error("Failed to load history:", error);
    }
    setIsLoaded(true);
  }, []);

  // Save history to localStorage when it changes
  useEffect(() => {
    if (isLoaded) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
    }
  }, [history, isLoaded]);

  const handleScanComplete = (result: DiagnosticResult) => {
    setHistory((prev) => [result, ...prev]);
    setSelectedResult(result);
  };

  const handleSelectScan = (result: DiagnosticResult) => {
    setSelectedResult(result);
  };

  const handleCategoryChange = (category: DiagnosticCategory) => {
    setSelectedCategory(category);
  };

  const handleProRequired = () => {
    setIsProModalOpen(true);
  };

  const handleOpenSavedScans = () => {
    const historySection = document.getElementById("scan-history");
    if (historySection) {
      historySection.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <main className="min-h-screen bg-background">
      {/* Header - Pure Black with Chrome Logo */}
      <header className="sticky top-0 z-10 bg-black border-b border-zinc-800">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <ChromeLogo size="md" />
            <div className="hidden sm:block">
              <h1 className="text-sm font-medium text-zinc-300">Car Sound Diagnostics</h1>
              <p className="text-xs text-zinc-600">Automotive Health Analysis</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <UserMenu onOpenSavedScans={handleOpenSavedScans} />
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="size-10 rounded-lg border border-zinc-700 bg-zinc-800/50 flex items-center justify-center text-zinc-400 hover:bg-zinc-800 hover:text-zinc-300 transition-colors"
              aria-label="Settings"
            >
              <Settings className="size-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
        {/* Category Selector */}
        <CategorySelector
          selectedCategory={selectedCategory}
          onCategoryChange={handleCategoryChange}
          onProRequired={handleProRequired}
        />

        {/* New Scan Button - Metallic Primary */}
        <Button
          onClick={() => setIsModalOpen(true)}
          size="lg"
          className="w-full h-14 text-base metallic-btn-primary text-white font-medium"
        >
          <Plus className="mr-2 size-5" />
          New Scan
        </Button>

        {/* OBD-II Dashboard */}
        <OBDDashboard
          isActive={isOBDActive}
          onToggle={() => setIsOBDActive(!isOBDActive)}
          onProRequired={handleProRequired}
        />

        {/* Results Card */}
        <DiagnosticCard result={selectedResult} />

        {/* Scan History */}
        <div id="scan-history">
          <ScanHistory
            history={history}
            onSelectScan={handleSelectScan}
            selectedId={selectedResult?.id ?? null}
          />
        </div>
      </div>

      {/* Scan Modal */}
      <ScanModal
        open={isModalOpen}
        onOpenChange={setIsModalOpen}
        onScanComplete={handleScanComplete}
        category={selectedCategory}
      />

      {/* Settings Modal */}
      <SettingsModal
        open={isSettingsOpen}
        onOpenChange={setIsSettingsOpen}
      />

      {/* Pro Upsell Modal */}
      <ProUpsellModal
        open={isProModalOpen}
        onOpenChange={setIsProModalOpen}
      />
    </main>
  );
}
