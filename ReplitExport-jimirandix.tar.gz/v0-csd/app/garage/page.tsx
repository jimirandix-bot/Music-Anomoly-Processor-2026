"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import { 
  ArrowLeft, 
  Cloud, 
  Warehouse, 
  CheckCircle, 
  AlertTriangle, 
  XCircle,
  Mic,
  Upload,
  Trash2,
  FileDown,
  Settings
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ChromeLogo } from "@/components/chrome-logo";
import { UserMenu } from "@/components/user-menu";
import { useDemo } from "@/lib/demo-context";
import { usePro } from "@/lib/pro-context";
import { type DiagnosticResult } from "@/lib/acoustics";

const STORAGE_KEY = "acoustic-diagnostics-history";

const statusIcons = {
  green: CheckCircle,
  amber: AlertTriangle,
  red: XCircle,
};

const statusColors = {
  green: "text-emerald-400",
  amber: "text-amber-400",
  red: "text-red-400",
};

const statusLabels = {
  green: "Healthy",
  amber: "Attention",
  red: "Critical",
};

export default function CloudGaragePage() {
  const { data: session, status } = useSession();
  const { isDemoMode, demoUser } = useDemo();
  const { isPro } = usePro();
  const [history, setHistory] = useState<DiagnosticResult[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  const isAuthenticated = isDemoMode || !!session;
  const currentUser = isDemoMode ? demoUser : session?.user;

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as DiagnosticResult[];
        setHistory(parsed);
      }
    } catch (error) {
      console.error("Failed to load history:", error);
    }
    setIsLoaded(true);
  }, []);

  const handleDelete = (id: string) => {
    const updated = history.filter((scan) => scan.id !== id);
    setHistory(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  };

  const handleClearAll = () => {
    if (confirm("Are you sure you want to delete all scan history?")) {
      setHistory([]);
      localStorage.setItem(STORAGE_KEY, JSON.stringify([]));
    }
  };

  if (status === "loading" && !isDemoMode) {
    return (
      <main className="min-h-screen bg-background flex items-center justify-center">
        <div className="size-8 rounded-full border-2 border-zinc-700 border-t-accent animate-spin" />
      </main>
    );
  }

  if (!isAuthenticated) {
    return (
      <main className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full bg-card border-zinc-800">
          <CardContent className="pt-6 text-center">
            <Warehouse className="size-16 mx-auto mb-4 text-zinc-600" />
            <h1 className="text-xl font-bold text-zinc-100 mb-2">Sign In Required</h1>
            <p className="text-zinc-400 mb-6">
              Please sign in to access your Cloud Garage and view saved reports from any device.
            </p>
            <Link href="/">
              <Button className="metallic-btn-primary text-white">
                <ArrowLeft className="mr-2 size-4" />
                Back to Home
              </Button>
            </Link>
          </CardContent>
        </Card>
      </main>
    );
  }

  const stats = {
    total: history.length,
    healthy: history.filter((s) => s.status === "green").length,
    attention: history.filter((s) => s.status === "amber").length,
    critical: history.filter((s) => s.status === "red").length,
  };

  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-black border-b border-zinc-800">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <ChromeLogo size="sm" />
            </Link>
            <div className="hidden sm:flex items-center gap-2 text-zinc-400">
              <ArrowLeft className="size-4" />
              <span className="text-sm">Cloud Garage</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <UserMenu />
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        {/* Page Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="size-12 rounded-lg bg-gradient-to-br from-zinc-700 to-zinc-900 flex items-center justify-center border border-zinc-700">
                <Cloud className="size-6 text-zinc-300" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-zinc-100">Cloud Garage</h1>
                <p className="text-sm text-zinc-500">
                  {currentUser?.name}&apos;s saved reports
                  {isDemoMode && <span className="ml-2 text-amber-400">(Demo)</span>}
                </p>
              </div>
            </div>
          </div>
          {history.length > 0 && (
            <Button
              onClick={handleClearAll}
              variant="outline"
              size="sm"
              className="border-red-500/30 text-red-400 hover:bg-red-500/10 hover:text-red-300"
            >
              <Trash2 className="mr-2 size-4" />
              Clear All
            </Button>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <Card className="bg-card border-zinc-800">
            <CardContent className="p-4">
              <p className="text-xs text-zinc-500 mb-1">Total Scans</p>
              <p className="text-2xl font-bold text-zinc-100">{stats.total}</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-zinc-800">
            <CardContent className="p-4">
              <p className="text-xs text-zinc-500 mb-1">Healthy</p>
              <p className="text-2xl font-bold text-emerald-400">{stats.healthy}</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-zinc-800">
            <CardContent className="p-4">
              <p className="text-xs text-zinc-500 mb-1">Attention</p>
              <p className="text-2xl font-bold text-amber-400">{stats.attention}</p>
            </CardContent>
          </Card>
          <Card className="bg-card border-zinc-800">
            <CardContent className="p-4">
              <p className="text-xs text-zinc-500 mb-1">Critical</p>
              <p className="text-2xl font-bold text-red-400">{stats.critical}</p>
            </CardContent>
          </Card>
        </div>

        {/* Reports List */}
        <Card className="bg-card border-zinc-800">
          <CardHeader>
            <CardTitle className="text-zinc-100">Saved Reports</CardTitle>
            <CardDescription className="text-zinc-500">
              Your diagnostic history synced across all devices
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            {!isLoaded ? (
              <div className="flex items-center justify-center py-12">
                <div className="size-8 rounded-full border-2 border-zinc-700 border-t-accent animate-spin" />
              </div>
            ) : history.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center px-4">
                <Warehouse className="size-16 text-zinc-700 mb-4" />
                <p className="text-zinc-400 text-lg font-medium mb-1">No reports yet</p>
                <p className="text-zinc-600 text-sm mb-4">
                  Start scanning to build your diagnostic history
                </p>
                <Link href="/">
                  <Button className="metallic-btn-primary text-white">
                    Start Scanning
                  </Button>
                </Link>
              </div>
            ) : (
              <ScrollArea className="h-[400px]">
                <div className="divide-y divide-zinc-800">
                  {history.map((scan) => {
                    const StatusIcon = statusIcons[scan.status];

                    return (
                      <div
                        key={scan.id}
                        className="flex items-start gap-4 p-4 hover:bg-zinc-800/30 transition-colors"
                      >
                        <StatusIcon className={`size-6 shrink-0 mt-0.5 ${statusColors[scan.status]}`} />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className={`text-xs font-medium px-2 py-0.5 rounded ${
                              scan.status === "green" 
                                ? "bg-emerald-500/20 text-emerald-400"
                                : scan.status === "amber"
                                  ? "bg-amber-500/20 text-amber-400"
                                  : "bg-red-500/20 text-red-400"
                            }`}>
                              {statusLabels[scan.status]}
                            </span>
                            <span className={`flex items-center gap-1 text-xs ${
                              scan.source === "live" ? "text-accent" : "text-zinc-500"
                            }`}>
                              {scan.source === "live" ? (
                                <Mic className="size-3" />
                              ) : (
                                <Upload className="size-3" />
                              )}
                              {scan.source === "live" ? "Live" : "Upload"}
                            </span>
                          </div>
                          <p className="text-sm font-medium text-zinc-200 mb-1">
                            {scan.signature}
                          </p>
                          <p className="text-xs text-zinc-500 line-clamp-2">
                            {scan.recommendation}
                          </p>
                          <p className="text-xs text-zinc-600 mt-2">
                            {new Date(scan.timestamp).toLocaleDateString(undefined, {
                              weekday: "short",
                              year: "numeric",
                              month: "short",
                              day: "numeric",
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </p>
                        </div>
                        <div className="flex items-center gap-1">
                          {isPro && (
                            <Button
                              size="sm"
                              variant="ghost"
                              className="size-8 p-0 text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800"
                              title="Download PDF (Pro)"
                            >
                              <FileDown className="size-4" />
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDelete(scan.id)}
                            className="size-8 p-0 text-zinc-500 hover:text-red-400 hover:bg-red-500/10"
                            title="Delete"
                          >
                            <Trash2 className="size-4" />
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>

        {/* Pro Upsell */}
        {!isPro && history.length > 0 && (
          <Card className="bg-gradient-to-r from-amber-500/10 via-orange-500/10 to-amber-500/10 border-amber-500/30">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-amber-400 mb-1">
                  Upgrade to Pro for PDF Reports
                </p>
                <p className="text-xs text-zinc-500">
                  Download shareable PDF reports for your mechanic
                </p>
              </div>
              <Link href="/">
                <Button size="sm" className="bg-gradient-to-r from-amber-500 to-orange-500 text-black font-medium">
                  Upgrade
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </main>
  );
}
