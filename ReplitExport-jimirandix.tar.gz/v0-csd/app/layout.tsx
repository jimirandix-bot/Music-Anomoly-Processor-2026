import type { Metadata } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import { Orbitron } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import { SessionProvider } from '@/components/session-provider'
import { ProProvider } from '@/lib/pro-context'
import { DemoProvider } from '@/lib/demo-context'
import './globals.css'

const _geist = Geist({ subsets: ["latin"] });
const _geistMono = Geist_Mono({ subsets: ["latin"] });
const _orbitron = Orbitron({ 
  subsets: ["latin"],
  weight: ["700"],
  variable: "--font-orbitron",
});

export const metadata: Metadata = {
  title: 'Car Sound Diagnostics',
  description: 'Professional automotive sound diagnostics and mechanical health analysis',
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport = {
  themeColor: '#18181b',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark bg-background">
      <body className="font-sans antialiased">
        <SessionProvider>
          <DemoProvider>
            <ProProvider>
              {children}
            </ProProvider>
          </DemoProvider>
        </SessionProvider>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
