"use client";

import { useState } from "react";
import { Sparkles, Check, Loader2, Zap, FileText, Cpu, Crown } from "lucide-react";
import confetti from "canvas-confetti";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { usePro } from "@/lib/pro-context";

interface ProUpsellModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

type PricingPlan = "monthly" | "lifetime";

const FEATURES = [
  {
    icon: Zap,
    title: "Full System Coverage",
    description: "Transmission, Brakes, Suspension, AC/HVAC diagnostics",
  },
  {
    icon: Cpu,
    title: "Hybrid OBD-II Analysis",
    description: "Real-time RPM, Fuel Trim, and Misfire monitoring",
  },
  {
    icon: FileText,
    title: "Shareable PDF Health Reports",
    description: "Professional reports to share with mechanics",
  },
];

export function ProUpsellModal({ open, onOpenChange }: ProUpsellModalProps) {
  const { setIsPro } = usePro();
  const [selectedPlan, setSelectedPlan] = useState<PricingPlan>("lifetime");
  const [isProcessing, setIsProcessing] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleCheckout = async () => {
    setIsProcessing(true);
    
    // Simulate checkout processing
    await new Promise((resolve) => setTimeout(resolve, 2000));
    
    setIsProcessing(false);
    setShowSuccess(true);
    setIsPro(true);

    // Fire confetti with chrome/gold colors
    const duration = 3000;
    const end = Date.now() + duration;

    const colors = ["#f59e0b", "#d97706", "#fbbf24", "#a3a3a3", "#737373"];

    (function frame() {
      confetti({
        particleCount: 4,
        angle: 60,
        spread: 55,
        origin: { x: 0, y: 0.7 },
        colors: colors,
      });
      confetti({
        particleCount: 4,
        angle: 120,
        spread: 55,
        origin: { x: 1, y: 0.7 },
        colors: colors,
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    })();

    // Auto close after celebration
    setTimeout(() => {
      setShowSuccess(false);
      onOpenChange(false);
    }, 3500);
  };

  const handleClose = (value: boolean) => {
    if (!isProcessing && !showSuccess) {
      onOpenChange(value);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg bg-zinc-900 border-zinc-700">
        {showSuccess ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="size-20 rounded-full bg-gradient-to-br from-amber-400 via-orange-500 to-amber-600 flex items-center justify-center mb-6 pro-glow">
              <Crown className="size-10 text-black" />
            </div>
            <h2 className="text-2xl font-bold text-zinc-100 mb-2">
              Welcome to Pro!
            </h2>
            <p className="text-zinc-400">
              You now have access to all premium features.
            </p>
            <div className="mt-4 px-4 py-2 rounded-lg bg-gradient-to-r from-amber-500 to-orange-500 text-black font-bold text-sm">
              CSD PRO UNLOCKED
            </div>
          </div>
        ) : (
          <>
            <DialogHeader className="text-center pb-2">
              <div className="mx-auto mb-4 size-16 rounded-full bg-gradient-to-br from-amber-400 via-orange-500 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/30">
                <Sparkles className="size-8 text-black" />
              </div>
              <DialogTitle className="text-2xl text-zinc-100">
                Unlock CSD Pro
              </DialogTitle>
              <DialogDescription className="text-zinc-400">
                Get complete diagnostic coverage for your vehicle
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6 py-4">
              {/* Features */}
              <div className="space-y-3">
                {FEATURES.map((feature) => (
                  <div
                    key={feature.title}
                    className="flex items-start gap-3 p-3 rounded-lg bg-zinc-800/50 border border-zinc-700"
                  >
                    <div className="size-8 rounded-lg bg-accent/20 flex items-center justify-center flex-shrink-0">
                      <feature.icon className="size-4 text-accent" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-zinc-200">
                        {feature.title}
                      </p>
                      <p className="text-xs text-zinc-500">{feature.description}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Pricing Options */}
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setSelectedPlan("monthly")}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    selectedPlan === "monthly"
                      ? "border-accent bg-accent/10"
                      : "border-zinc-700 hover:border-zinc-600 bg-zinc-800/30"
                  }`}
                >
                  <p className="text-xs text-zinc-500 mb-1">Monthly</p>
                  <p className="text-2xl font-bold text-zinc-100">
                    $4.99
                    <span className="text-sm font-normal text-zinc-500">/mo</span>
                  </p>
                </button>
                <button
                  onClick={() => setSelectedPlan("lifetime")}
                  className={`p-4 rounded-lg border-2 transition-all relative ${
                    selectedPlan === "lifetime"
                      ? "border-amber-500 bg-amber-500/10"
                      : "border-zinc-700 hover:border-zinc-600 bg-zinc-800/30"
                  }`}
                >
                  <span className="absolute -top-2 left-1/2 -translate-x-1/2 px-2 py-0.5 bg-gradient-to-r from-amber-500 to-orange-500 text-black text-[10px] font-bold rounded-full">
                    BEST VALUE
                  </span>
                  <p className="text-xs text-zinc-500 mb-1">Lifetime</p>
                  <p className="text-2xl font-bold text-zinc-100">$29.99</p>
                </button>
              </div>

              {/* Checkout Button */}
              <Button
                onClick={handleCheckout}
                disabled={isProcessing}
                className="w-full h-14 text-base bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-600 hover:via-orange-600 hover:to-amber-700 text-black font-bold shadow-lg shadow-amber-500/20"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="mr-2 size-5 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Check className="mr-2 size-5" />
                    Simulate Checkout
                  </>
                )}
              </Button>

              <p className="text-xs text-center text-zinc-600">
                This is a demo. No actual payment will be processed.
              </p>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
