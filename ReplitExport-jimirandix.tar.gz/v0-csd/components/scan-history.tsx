"use client";

import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { type DiagnosticResult } from "@/lib/acoustics";
import { Mic, Upload, CheckCircle, AlertTriangle, XCircle, Clock } from "lucide-react";

interface ScanHistoryProps {
  history: DiagnosticResult[];
  onSelectScan: (result: DiagnosticResult) => void;
  selectedId: string | null;
}

const statusIcons = {
  green: CheckCircle,
  amber: AlertTriangle,
  red: XCircle,
};

const statusColors = {
  green: "text-emerald-400",
  amber: "text-amber-400",
  red: "text-red-400",
};

export function ScanHistory({ history, onSelectScan, selectedId }: ScanHistoryProps) {
  if (history.length === 0) {
    return (
      <Card className="bg-card border-zinc-800">
        <CardHeader>
          <CardTitle className="text-zinc-100 flex items-center gap-2">
            <Clock className="size-5 text-zinc-500" />
            Scan History
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-zinc-600 text-center py-8">
            Your past scans will appear here
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card border-zinc-800">
      <CardHeader>
        <CardTitle className="text-zinc-100 flex items-center gap-2">
          <Clock className="size-5 text-zinc-500" />
          Scan History
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-64">
          <div className="divide-y divide-zinc-800">
            {history.map((scan) => {
              const StatusIcon = statusIcons[scan.status];
              const isSelected = scan.id === selectedId;

              return (
                <button
                  key={scan.id}
                  onClick={() => onSelectScan(scan)}
                  className={`w-full flex items-center gap-3 p-4 text-left transition-colors hover:bg-zinc-800/50 ${
                    isSelected ? "bg-zinc-800/50" : ""
                  }`}
                >
                  <StatusIcon className={`size-5 shrink-0 ${statusColors[scan.status]}`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-zinc-200 truncate">
                      {scan.signature}
                    </p>
                    <p className="text-xs text-zinc-600">
                      {new Date(scan.timestamp).toLocaleDateString(undefined, {
                        month: "short",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                  <div
                    className={`flex items-center gap-1 px-2 py-1 rounded text-xs font-medium ${
                      scan.source === "live"
                        ? "bg-accent/20 text-accent"
                        : "bg-zinc-800 text-zinc-400"
                    }`}
                  >
                    {scan.source === "live" ? (
                      <Mic className="size-3" />
                    ) : (
                      <Upload className="size-3" />
                    )}
                    {scan.source === "live" ? "Live" : "Uploaded"}
                  </div>
                </button>
              );
            })}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
