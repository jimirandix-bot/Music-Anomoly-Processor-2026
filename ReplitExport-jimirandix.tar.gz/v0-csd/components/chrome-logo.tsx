"use client";

import "@fontsource/orbitron/700.css";
import { usePro } from "@/lib/pro-context";

interface ChromeLogoProps {
  size?: "sm" | "md" | "lg";
}

export function ChromeLogo({ size = "md" }: ChromeLogoProps) {
  const { isPro } = usePro();
  
  const sizeClasses = {
    sm: "text-lg",
    md: "text-2xl",
    lg: "text-4xl",
  };

  return (
    <div className={`relative ${isPro ? "pro-glow rounded-lg" : ""}`}>
      <div 
        className={`
          px-3 py-1.5 rounded-lg
          bg-gradient-to-b from-zinc-800 via-zinc-900 to-black
          border border-zinc-700
          shadow-lg shadow-black/50
        `}
      >
        <span 
          className={`
            font-['Orbitron'] font-bold tracking-wider
            ${sizeClasses[size]}
            chrome-text
          `}
          style={{ fontFamily: "'Orbitron', sans-serif" }}
        >
          CSD
        </span>
        {isPro && (
          <span 
            className="
              ml-2 px-1.5 py-0.5 
              text-[10px] font-bold tracking-wide
              bg-gradient-to-r from-amber-500 via-orange-400 to-amber-500
              text-black rounded
              animate-pulse
            "
          >
            PRO
          </span>
        )}
      </div>
    </div>
  );
}
