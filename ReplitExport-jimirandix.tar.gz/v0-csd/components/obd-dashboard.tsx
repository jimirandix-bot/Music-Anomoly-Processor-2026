"use client";

import { useState, useEffect } from "react";
import { Activity, Gauge, Flame, AlertTriangle, Lock, Sparkles } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { usePro } from "@/lib/pro-context";

interface OBDData {
  rpm: number;
  fuelTrimShort: number;
  fuelTrimLong: number;
  misfires: {
    cyl1: number;
    cyl2: number;
    cyl3: number;
    cyl4: number;
  };
}

interface OBDDashboardProps {
  isActive: boolean;
  onToggle: () => void;
  onProRequired: () => void;
}

export function OBDDashboard({ isActive, onToggle, onProRequired }: OBDDashboardProps) {
  const { isPro } = usePro();
  const [data, setData] = useState<OBDData>({
    rpm: 850,
    fuelTrimShort: 0,
    fuelTrimLong: 2.5,
    misfires: { cyl1: 0, cyl2: 0, cyl3: 0, cyl4: 0 },
  });

  // Simulate live OBD-II data
  useEffect(() => {
    if (!isActive || !isPro) return;

    const interval = setInterval(() => {
      setData((prev) => ({
        rpm: Math.round(800 + Math.random() * 200 + Math.sin(Date.now() / 1000) * 50),
        fuelTrimShort: parseFloat((Math.random() * 6 - 3).toFixed(1)),
        fuelTrimLong: parseFloat((prev.fuelTrimLong + (Math.random() * 0.4 - 0.2)).toFixed(1)),
        misfires: {
          cyl1: prev.misfires.cyl1 + (Math.random() < 0.02 ? 1 : 0),
          cyl2: prev.misfires.cyl2 + (Math.random() < 0.01 ? 1 : 0),
          cyl3: prev.misfires.cyl3 + (Math.random() < 0.015 ? 1 : 0),
          cyl4: prev.misfires.cyl4 + (Math.random() < 0.01 ? 1 : 0),
        },
      }));
    }, 500);

    return () => clearInterval(interval);
  }, [isActive, isPro]);

  const handleToggle = () => {
    if (!isPro) {
      onProRequired();
      return;
    }
    onToggle();
  };

  const totalMisfires = data.misfires.cyl1 + data.misfires.cyl2 + data.misfires.cyl3 + data.misfires.cyl4;

  return (
    <Card className="bg-card border-zinc-800">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CardTitle className="text-base text-zinc-100">OBD-II Hybrid Mode</CardTitle>
            <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-gradient-to-r from-amber-500 to-orange-500 text-black rounded flex items-center gap-0.5">
              <Sparkles className="size-2.5" />
              PRO
            </span>
          </div>
          <Button
            onClick={handleToggle}
            size="sm"
            className={
              isActive && isPro
                ? "metallic-btn-primary text-white"
                : "metallic-btn text-zinc-300"
            }
          >
            {!isPro && <Lock className="mr-1.5 size-3" />}
            {isActive && isPro ? "Active" : "Activate"}
          </Button>
        </div>
        <CardDescription className="text-zinc-500">
          Real-time engine telemetry via simulated OBD-II connection
        </CardDescription>
      </CardHeader>

      {isActive && isPro && (
        <CardContent className="pt-0">
          <div className="grid grid-cols-2 gap-3">
            {/* RPM */}
            <div className="p-3 rounded-lg bg-zinc-800/50 border border-zinc-700">
              <div className="flex items-center gap-2 mb-2">
                <Gauge className="size-4 text-accent" />
                <span className="text-xs font-medium text-zinc-500">RPM</span>
              </div>
              <p className="text-2xl font-bold text-zinc-100 font-mono">
                {data.rpm}
              </p>
            </div>

            {/* Fuel Trim */}
            <div className="p-3 rounded-lg bg-zinc-800/50 border border-zinc-700">
              <div className="flex items-center gap-2 mb-2">
                <Flame className="size-4 text-orange-400" />
                <span className="text-xs font-medium text-zinc-500">Fuel Trim</span>
              </div>
              <div className="flex items-baseline gap-2">
                <p className="text-lg font-bold text-zinc-100 font-mono">
                  {data.fuelTrimShort > 0 ? "+" : ""}{data.fuelTrimShort}%
                </p>
                <span className="text-xs text-zinc-600">Short</span>
              </div>
              <div className="flex items-baseline gap-2">
                <p className="text-sm font-medium text-zinc-400 font-mono">
                  {data.fuelTrimLong > 0 ? "+" : ""}{data.fuelTrimLong}%
                </p>
                <span className="text-xs text-zinc-600">Long</span>
              </div>
            </div>

            {/* Misfires */}
            <div className="col-span-2 p-3 rounded-lg bg-zinc-800/50 border border-zinc-700">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <AlertTriangle className={`size-4 ${totalMisfires > 5 ? "text-amber-400" : "text-zinc-600"}`} />
                  <span className="text-xs font-medium text-zinc-500">Misfire Count</span>
                </div>
                <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                  totalMisfires === 0 
                    ? "bg-emerald-500/20 text-emerald-400" 
                    : totalMisfires < 5 
                      ? "bg-amber-500/20 text-amber-400"
                      : "bg-red-500/20 text-red-400"
                }`}>
                  {totalMisfires === 0 ? "None" : `${totalMisfires} total`}
                </span>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {[1, 2, 3, 4].map((cyl) => {
                  const count = data.misfires[`cyl${cyl}` as keyof typeof data.misfires];
                  return (
                    <div key={cyl} className="text-center">
                      <p className="text-xs text-zinc-600 mb-1">Cyl {cyl}</p>
                      <p className={`text-lg font-bold font-mono ${
                        count === 0 ? "text-zinc-600" : count < 3 ? "text-amber-400" : "text-red-400"
                      }`}>
                        {count}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* JSON Preview */}
          <div className="mt-3 p-3 rounded-lg bg-black border border-zinc-800 overflow-x-auto">
            <pre className="text-xs text-emerald-400 font-mono">
{JSON.stringify({
  rpm: data.rpm,
  fuel_trim: {
    short_term: data.fuelTrimShort,
    long_term: data.fuelTrimLong
  },
  misfires: data.misfires
}, null, 2)}
            </pre>
          </div>
        </CardContent>
      )}
    </Card>
  );
}
