"use client";

import { useState, useRef, useCallback, useEffect } from "react";
import { Mic, Upload, Square, Loader2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AudioVisualizer } from "@/components/audio-visualizer";
import { analyzeCarAudio, type DiagnosticResult, type DiagnosticCategory } from "@/lib/acoustics";
import { getGeminiApiKey } from "@/components/settings-modal";

interface ScanModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onScanComplete: (result: DiagnosticResult) => void;
  category?: DiagnosticCategory;
}

type ScanMode = "select" | "recording" | "analyzing";

export function ScanModal({ open, onOpenChange, onScanComplete, category = "engine" }: ScanModalProps) {
  const [mode, setMode] = useState<ScanMode>("select");
  const [recordingTime, setRecordingTime] = useState(0);
  const [analyser, setAnalyser] = useState<AnalyserNode | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const streamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const cleanup = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop();
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    setAnalyser(null);
    audioChunksRef.current = [];
  }, []);

  useEffect(() => {
    if (!open) {
      cleanup();
      setMode("select");
      setRecordingTime(0);
    }
  }, [open, cleanup]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const audioContext = new AudioContext();
      audioContextRef.current = audioContext;
      const source = audioContext.createMediaStreamSource(stream);
      const analyserNode = audioContext.createAnalyser();
      analyserNode.fftSize = 256;
      source.connect(analyserNode);
      setAnalyser(analyserNode);

      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: "audio/webm" });
        await processAudio(audioBlob, "live");
      };

      mediaRecorder.start();
      setMode("recording");
      setRecordingTime(0);

      timerRef.current = setInterval(() => {
        setRecordingTime((prev) => {
          if (prev >= 10) {
            stopRecording();
            return 10;
          }
          return prev + 1;
        });
      }, 1000);
    } catch (error) {
      console.error("Error accessing microphone:", error);
      alert("Unable to access microphone. Please check permissions.");
    }
  };

  const stopRecording = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop();
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
    }
    setMode("analyzing");
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setMode("analyzing");
    await processAudio(file, "uploaded");
  };

  const processAudio = async (data: Blob | File, source: "live" | "uploaded") => {
    try {
      const apiKey = getGeminiApiKey();
      const result = await analyzeCarAudio(data, source, apiKey, category);
      onScanComplete(result);
      onOpenChange(false);
    } catch (error) {
      console.error("Analysis failed:", error);
      setMode("select");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-zinc-900 border-zinc-700">
        <DialogHeader>
          <DialogTitle className="text-zinc-100">
            {mode === "select" && "New Acoustic Scan"}
            {mode === "recording" && "Recording Audio"}
            {mode === "analyzing" && "Analyzing Audio"}
          </DialogTitle>
          <DialogDescription className="text-zinc-400">
            {mode === "select" && "Choose how to capture the audio sample"}
            {mode === "recording" && `Recording: ${recordingTime}s / 10s`}
            {mode === "analyzing" && "Processing acoustic signature..."}
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          {mode === "select" && (
            <div className="flex flex-col gap-3">
              <Button
                onClick={startRecording}
                className="h-14 text-base metallic-btn-primary text-white"
              >
                <Mic className="mr-2 size-5" />
                Live Record
              </Button>
              <Button
                onClick={() => fileInputRef.current?.click()}
                className="h-14 text-base metallic-btn text-zinc-200"
              >
                <Upload className="mr-2 size-5" />
                Upload File
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".wav,.mp3,audio/wav,audio/mp3,audio/mpeg"
                onChange={handleFileUpload}
                className="hidden"
              />
              <p className="text-center text-sm text-zinc-500 mt-2">
                Supports .wav and .mp3 files
              </p>
            </div>
          )}

          {mode === "recording" && (
            <div className="flex flex-col items-center gap-4">
              <AudioVisualizer analyser={analyser} isRecording={true} />
              <div className="flex items-center gap-2">
                <span className="relative flex size-3">
                  <span className="absolute inline-flex size-full animate-ping rounded-full bg-red-400 opacity-75" />
                  <span className="relative inline-flex size-3 rounded-full bg-red-500" />
                </span>
                <span className="text-sm text-zinc-400 font-medium">
                  {recordingTime}s / 10s
                </span>
              </div>
              <Button
                onClick={stopRecording}
                className="metallic-btn text-zinc-200"
              >
                <Square className="mr-2 size-4 fill-current" />
                Stop Recording
              </Button>
            </div>
          )}

          {mode === "analyzing" && (
            <div className="flex flex-col items-center gap-4 py-8">
              <Loader2 className="size-12 text-accent animate-spin" />
              <p className="text-zinc-300 font-medium">Analyzing acoustic signature...</p>
              <p className="text-sm text-zinc-500">This may take a few seconds</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
