"use client";

import { useState } from "react";
import { useSession, signIn, signOut } from "next-auth/react";
import { User, LogOut, History, Crown, ChevronDown, Mail, Zap, Warehouse } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { usePro } from "@/lib/pro-context";
import { useDemo } from "@/lib/demo-context";
import Link from "next/link";

interface UserMenuProps {
  onOpenSavedScans?: () => void;
}

export function UserMenu({ onOpenSavedScans }: UserMenuProps) {
  const { data: session, status } = useSession();
  const { isPro } = usePro();
  const { isDemoMode, demoUser, enterDemoMode, exitDemoMode } = useDemo();
  const [isSignInOpen, setIsSignInOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [isEmailLoading, setIsEmailLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);

  const handleGoogleSignIn = async () => {
    setIsGoogleLoading(true);
    try {
      await signIn("google");
    } catch {
      // If Google sign-in fails, show the modal with demo option
      setIsGoogleLoading(false);
      setIsSignInOpen(true);
    }
  };

  const handleEmailSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    
    setIsEmailLoading(true);
    try {
      await signIn("resend", { email, callbackUrl: "/" });
    } catch {
      setIsEmailLoading(false);
    }
  };

  const handleDemoMode = () => {
    enterDemoMode();
    setIsSignInOpen(false);
  };

  const handleSignOut = async () => {
    if (isDemoMode) {
      exitDemoMode();
    } else {
      await signOut();
    }
  };

  // Use demo user if in demo mode
  const currentUser = isDemoMode ? demoUser : session?.user;
  const isAuthenticated = isDemoMode || !!session;

  if (status === "loading" && !isDemoMode) {
    return (
      <div className="size-10 rounded-lg border border-zinc-700 animate-pulse bg-zinc-800" />
    );
  }

  if (!isAuthenticated) {
    return (
      <>
        <Button
          onClick={() => setIsSignInOpen(true)}
          className="h-10 px-4 metallic-btn text-zinc-200"
        >
          <User className="mr-2 size-4" />
          Sign In
        </Button>

        <Dialog open={isSignInOpen} onOpenChange={setIsSignInOpen}>
          <DialogContent className="sm:max-w-md bg-zinc-900 border-zinc-700">
            <DialogHeader>
              <DialogTitle className="text-zinc-100">Sign in to CSD</DialogTitle>
              <DialogDescription className="text-zinc-400">
                Choose your preferred sign-in method
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              {/* Google Sign In */}
              <Button
                onClick={handleGoogleSignIn}
                disabled={isGoogleLoading}
                className="w-full h-12 metallic-btn text-zinc-200"
              >
                <svg className="mr-2 size-5" viewBox="0 0 24 24">
                  <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                {isGoogleLoading ? "Signing in..." : "Continue with Google"}
              </Button>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-zinc-700" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-zinc-900 px-2 text-zinc-500">Or</span>
                </div>
              </div>

              {/* Email Sign In */}
              <form onSubmit={handleEmailSignIn} className="space-y-3">
                <input
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full h-12 px-4 rounded-lg bg-zinc-800 border border-zinc-700 text-zinc-100 placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-accent"
                />
                <Button
                  type="submit"
                  disabled={isEmailLoading || !email}
                  className="w-full h-12 metallic-btn-primary text-white"
                >
                  <Mail className="mr-2 size-4" />
                  {isEmailLoading ? "Sending link..." : "Send Magic Link"}
                </Button>
              </form>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-zinc-700" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-zinc-900 px-2 text-zinc-500">Or try demo</span>
                </div>
              </div>

              {/* Demo Mode */}
              <Button
                onClick={handleDemoMode}
                variant="outline"
                className="w-full h-12 border-amber-500/50 text-amber-400 hover:bg-amber-500/10 hover:text-amber-300"
              >
                <Zap className="mr-2 size-4" />
                Enter Demo Mode
              </Button>
              <p className="text-xs text-center text-zinc-500">
                Demo mode lets you explore all features without signing in
              </p>
            </div>
          </DialogContent>
        </Dialog>
      </>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="flex items-center gap-2 h-10 px-3 rounded-lg border border-zinc-700 bg-zinc-800/50 hover:bg-zinc-800 transition-colors">
          {currentUser?.image ? (
            <img
              src={currentUser.image}
              alt={currentUser.name || "User"}
              className="size-6 rounded-full"
            />
          ) : (
            <div className="size-6 rounded-full bg-gradient-to-br from-zinc-600 to-zinc-800 flex items-center justify-center">
              <User className="size-3 text-zinc-300" />
            </div>
          )}
          <span className="text-sm font-medium text-zinc-300 max-w-24 truncate hidden sm:block">
            {currentUser?.name?.split(" ")[0]}
          </span>
          {isDemoMode && (
            <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-amber-500/20 text-amber-400 rounded border border-amber-500/30">
              DEMO
            </span>
          )}
          {isPro && !isDemoMode && (
            <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-gradient-to-r from-amber-500 to-orange-500 text-black rounded">
              PRO
            </span>
          )}
          <ChevronDown className="size-4 text-zinc-500" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56 bg-zinc-900 border-zinc-700">
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium text-zinc-100">{currentUser?.name}</p>
            <p className="text-xs text-zinc-500 truncate">{currentUser?.email}</p>
            {isDemoMode && (
              <span className="text-xs text-amber-400">Demo Mode Active</span>
            )}
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator className="bg-zinc-700" />
        {isPro && (
          <DropdownMenuItem disabled className="text-amber-400">
            <Crown className="mr-2 size-4" />
            Pro Member
          </DropdownMenuItem>
        )}
        <DropdownMenuItem asChild>
          <Link href="/garage" className="flex items-center cursor-pointer text-zinc-300 hover:text-zinc-100">
            <Warehouse className="mr-2 size-4" />
            Cloud Garage
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={onOpenSavedScans} className="text-zinc-300 hover:text-zinc-100">
          <History className="mr-2 size-4" />
          My Saved Scans
        </DropdownMenuItem>
        <DropdownMenuSeparator className="bg-zinc-700" />
        <DropdownMenuItem onClick={handleSignOut} className="text-red-400 hover:text-red-300">
          <LogOut className="mr-2 size-4" />
          {isDemoMode ? "Exit Demo" : "Sign out"}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
