"use client";

import { useState } from "react";
import { ChevronDown, Sparkles, Lock } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { usePro } from "@/lib/pro-context";

export type DiagnosticCategory = 
  | "engine"
  | "transmission"
  | "brakes"
  | "suspension"
  | "hvac";

interface CategoryOption {
  id: DiagnosticCategory;
  label: string;
  description: string;
  isPro: boolean;
}

const CATEGORIES: CategoryOption[] = [
  {
    id: "engine",
    label: "Engine",
    description: "General engine sound analysis",
    isPro: false,
  },
  {
    id: "transmission",
    label: "Transmission",
    description: "Gear shifting and drivetrain sounds",
    isPro: true,
  },
  {
    id: "brakes",
    label: "Brakes",
    description: "Brake squeal and grinding detection",
    isPro: true,
  },
  {
    id: "suspension",
    label: "Suspension",
    description: "Shock and strut noise analysis",
    isPro: true,
  },
  {
    id: "hvac",
    label: "AC/HVAC",
    description: "Climate system noise detection",
    isPro: true,
  },
];

interface CategorySelectorProps {
  selectedCategory: DiagnosticCategory;
  onCategoryChange: (category: DiagnosticCategory) => void;
  onProRequired: () => void;
}

export function CategorySelector({
  selectedCategory,
  onCategoryChange,
  onProRequired,
}: CategorySelectorProps) {
  const { isPro } = usePro();
  const [isOpen, setIsOpen] = useState(false);

  const currentCategory = CATEGORIES.find((c) => c.id === selectedCategory) || CATEGORIES[0];

  const handleSelect = (category: CategoryOption) => {
    if (category.isPro && !isPro) {
      onProRequired();
      setIsOpen(false);
      return;
    }
    onCategoryChange(category.id);
    setIsOpen(false);
  };

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <button className="flex items-center justify-between w-full h-12 px-4 rounded-lg border border-zinc-700 bg-zinc-800/50 hover:bg-zinc-800 transition-colors">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-zinc-200">
              {currentCategory.label}
            </span>
            {currentCategory.isPro && isPro && (
              <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-gradient-to-r from-amber-500 to-orange-500 text-black rounded flex items-center gap-0.5">
                <Sparkles className="size-2.5" />
                PRO
              </span>
            )}
          </div>
          <ChevronDown className="size-4 text-zinc-500" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-64 bg-zinc-900 border-zinc-700">
        <DropdownMenuLabel className="text-zinc-400">Diagnostic Category</DropdownMenuLabel>
        <DropdownMenuSeparator className="bg-zinc-700" />
        {CATEGORIES.map((category) => (
          <DropdownMenuItem
            key={category.id}
            onClick={() => handleSelect(category)}
            className="flex items-center justify-between py-2.5 cursor-pointer text-zinc-300 hover:text-zinc-100 hover:bg-zinc-800"
          >
            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">
                  {category.label}
                </span>
                {category.isPro && (
                  <span className="px-1.5 py-0.5 text-[10px] font-semibold bg-gradient-to-r from-amber-500 to-orange-500 text-black rounded flex items-center gap-0.5">
                    <Sparkles className="size-2.5" />
                    PRO
                  </span>
                )}
              </div>
              <span className="text-xs text-zinc-500">{category.description}</span>
            </div>
            {category.isPro && !isPro && (
              <Lock className="size-4 text-zinc-600" />
            )}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export function getCategoryLabel(category: DiagnosticCategory): string {
  return CATEGORIES.find((c) => c.id === category)?.label || "Engine";
}
