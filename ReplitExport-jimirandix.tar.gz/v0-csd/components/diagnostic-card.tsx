"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { type DiagnosticResult } from "@/lib/acoustics";
import { CheckCircle, AlertTriangle, XCircle, Sparkles } from "lucide-react";

interface DiagnosticCardProps {
  result: DiagnosticResult | null;
}

const statusConfig = {
  green: {
    label: "Healthy",
    icon: CheckCircle,
    bgColor: "bg-emerald-500/10",
    borderColor: "border-emerald-500/30",
    iconColor: "text-emerald-400",
    textColor: "text-emerald-400",
  },
  amber: {
    label: "Attention Needed",
    icon: AlertTriangle,
    bgColor: "bg-amber-500/10",
    borderColor: "border-amber-500/30",
    iconColor: "text-amber-400",
    textColor: "text-amber-400",
  },
  red: {
    label: "Critical",
    icon: XCircle,
    bgColor: "bg-red-500/10",
    borderColor: "border-red-500/30",
    iconColor: "text-red-400",
    textColor: "text-red-400",
  },
};

export function DiagnosticCard({ result }: DiagnosticCardProps) {
  if (!result) {
    return (
      <Card className="bg-card border-zinc-800">
        <CardHeader>
          <CardTitle className="text-zinc-100">Mechanical Health Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="size-16 rounded-full bg-zinc-800 flex items-center justify-center mb-4">
              <Sparkles className="size-8 text-zinc-600" />
            </div>
            <p className="text-zinc-400 text-lg font-medium">No scan results yet</p>
            <p className="text-zinc-600 text-sm mt-1">
              Start a new scan to analyze your vehicle&apos;s acoustic signature
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const config = statusConfig[result.status];
  const StatusIcon = config.icon;

  return (
    <Card className="bg-card border-zinc-800">
      <CardHeader>
        <CardTitle className="text-zinc-100">Mechanical Health Summary</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Status Indicator */}
        <div
          className={`flex items-center gap-4 p-4 rounded-lg border ${config.bgColor} ${config.borderColor}`}
        >
          <StatusIcon className={`size-10 ${config.iconColor}`} />
          <div>
            <p className={`text-lg font-semibold ${config.textColor}`}>{config.label}</p>
            <p className="text-sm text-zinc-500">
              Scanned {new Date(result.timestamp).toLocaleString()}
            </p>
          </div>
        </div>

        {/* Detected Signature */}
        <div>
          <h4 className="text-sm font-medium text-zinc-500 uppercase tracking-wide mb-2">
            Detected Signature
          </h4>
          <p className="text-zinc-200 font-medium text-lg">{result.signature}</p>
        </div>

        {/* AI Recommendation */}
        <div className="border-t border-zinc-800 pt-6">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="size-4 text-accent" />
            <h4 className="text-sm font-medium text-zinc-500 uppercase tracking-wide">
              AI Recommendation
            </h4>
          </div>
          <p className="text-zinc-400 leading-relaxed">{result.recommendation}</p>
        </div>
      </CardContent>
    </Card>
  );
}
