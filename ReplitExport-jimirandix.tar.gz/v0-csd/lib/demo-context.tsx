"use client";

import { createContext, useContext, useState, type ReactNode } from "react";

interface DemoUser {
  name: string;
  email: string;
  image: string | null;
}

interface DemoContextType {
  isDemoMode: boolean;
  demoUser: DemoUser | null;
  enterDemoMode: () => void;
  exitDemoMode: () => void;
}

const DemoContext = createContext<DemoContextType | undefined>(undefined);

const DEMO_USER: DemoUser = {
  name: "Demo User",
  email: "demo@carsounddiagnostics.app",
  image: null,
};

export function DemoProvider({ children }: { children: ReactNode }) {
  const [isDemoMode, setIsDemoMode] = useState(false);
  const [demoUser, setDemoUser] = useState<DemoUser | null>(null);

  const enterDemoMode = () => {
    setIsDemoMode(true);
    setDemoUser(DEMO_USER);
  };

  const exitDemoMode = () => {
    setIsDemoMode(false);
    setDemoUser(null);
  };

  return (
    <DemoContext.Provider value={{ isDemoMode, demoUser, enterDemoMode, exitDemoMode }}>
      {children}
    </DemoContext.Provider>
  );
}

export function useDemo() {
  const context = useContext(DemoContext);
  if (context === undefined) {
    throw new Error("useDemo must be used within a DemoProvider");
  }
  return context;
}
