"use client";

import { createContext, useContext, useState, useEffect, type ReactNode } from "react";

interface ProContextType {
  isPro: boolean;
  setIsPro: (value: boolean) => void;
}

const ProContext = createContext<ProContextType | undefined>(undefined);

const PRO_STORAGE_KEY = "csd-pro-status";

export function ProProvider({ children }: { children: ReactNode }) {
  const [isPro, setIsProState] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(PRO_STORAGE_KEY);
    if (stored === "true") {
      setIsProState(true);
    }
    setIsLoaded(true);
  }, []);

  const setIsPro = (value: boolean) => {
    setIsProState(value);
    localStorage.setItem(PRO_STORAGE_KEY, value.toString());
  };

  if (!isLoaded) {
    return null;
  }

  return (
    <ProContext.Provider value={{ isPro, setIsPro }}>
      {children}
    </ProContext.Provider>
  );
}

export function usePro() {
  const context = useContext(ProContext);
  if (context === undefined) {
    throw new Error("usePro must be used within a ProProvider");
  }
  return context;
}
