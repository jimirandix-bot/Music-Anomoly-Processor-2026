export type DiagnosticStatus = "green" | "amber" | "red";

export interface DiagnosticResult {
  id: string;
  timestamp: number;
  status: DiagnosticStatus;
  signature: string;
  recommendation: string;
  source: "live" | "uploaded";
  duration: number;
}

interface GeminiResponse {
  candidates?: Array<{
    content?: {
      parts?: Array<{
        text?: string;
      }>;
    };
  }>;
  error?: {
    message: string;
  };
}

interface AnalysisResult {
  status: DiagnosticStatus;
  signature: string;
  recommendation: string;
}

async function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      // Remove the data URL prefix (e.g., "data:audio/wav;base64,")
      const base64Data = base64.split(",")[1];
      resolve(base64Data);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

function parseGeminiResponse(text: string): AnalysisResult {
  // Try to extract JSON from the response
  const jsonMatch = text.match(/\{[\s\S]*\}/);
  if (jsonMatch) {
    try {
      const parsed = JSON.parse(jsonMatch[0]);
      const status = (parsed.status?.toLowerCase() || "amber") as DiagnosticStatus;
      const validStatus = ["green", "amber", "red"].includes(status) ? status : "amber";
      return {
        status: validStatus,
        signature: parsed.signature || "Audio Pattern Analyzed",
        recommendation: parsed.recommendation || "Analysis complete. Please consult a professional for detailed assessment.",
      };
    } catch {
      // Fall through to text parsing
    }
  }

  // Fallback: parse from plain text
  let status: DiagnosticStatus = "amber";
  if (text.toLowerCase().includes("healthy") || text.toLowerCase().includes("green") || text.toLowerCase().includes("normal")) {
    status = "green";
  } else if (text.toLowerCase().includes("critical") || text.toLowerCase().includes("red") || text.toLowerCase().includes("severe") || text.toLowerCase().includes("urgent")) {
    status = "red";
  }

  return {
    status,
    signature: "Audio Pattern Analyzed",
    recommendation: text.slice(0, 500),
  };
}

export type DiagnosticCategory = "engine" | "transmission" | "brakes" | "suspension" | "hvac";

const CATEGORY_PROMPTS: Record<DiagnosticCategory, string> = {
  engine: `Focus on: engine idle patterns, valve train sounds, timing chain/belt noises, knock or ping sounds, exhaust leaks, and accessory drive belt sounds. Listen for irregular combustion patterns, lifter tick, rod knock, or bearing whine.`,
  transmission: `Focus on: gear engagement sounds, shifting noises, whining during acceleration/deceleration, grinding during shifts, torque converter sounds, and differential noise. Listen for slipping, harsh engagement, or delayed shifts.`,
  brakes: `Focus on: brake squeal, grinding, scraping, pulsation sounds, caliper drag, and pad wear indicators. Listen for high-frequency squeals indicating worn pads, grinding indicating metal-on-metal contact, or thumping from warped rotors.`,
  suspension: `Focus on: clunks over bumps, strut/shock sounds, ball joint pops, tie rod end noise, sway bar link rattles, and spring sounds. Listen for knocking, squeaking during turns, or excessive body roll sounds.`,
  hvac: `Focus on: blower motor sounds, compressor cycling, refrigerant flow noise, blend door actuator clicks, and ductwork vibrations. Listen for squealing from belts, grinding from bearings, or clicking from actuators.`,
};

export async function analyzeCarAudio(
  data: Blob | File,
  source: "live" | "uploaded",
  apiKey?: string | null,
  category: DiagnosticCategory = "engine"
): Promise<DiagnosticResult> {
  // If no API key, fall back to simulated analysis
  if (!apiKey) {
    return simulatedAnalysis(data, source, category);
  }

  try {
    // Convert audio to base64
    const base64Audio = await blobToBase64(data);
    
    // Determine MIME type
    const mimeType = data.type || "audio/wav";

    const categoryContext = CATEGORY_PROMPTS[category];
    const categoryLabel = category.toUpperCase();

    const prompt = `You are an expert automotive acoustic diagnostician specializing in ${categoryLabel} diagnostics. Analyze this audio recording from a vehicle's ${category} system and determine its mechanical health.

${categoryContext}

Listen carefully to the frequency patterns, rhythms, and any anomalies in the audio specific to ${category} components.

Respond with ONLY a JSON object in this exact format (no other text):
{
  "status": "green" | "amber" | "red",
  "signature": "A short description of what you detected specific to ${category} (e.g., 'Normal ${category} Operation', 'Intermittent ${category} Noise', 'Critical ${category} Issue')",
  "recommendation": "Your detailed recommendation based on the ${category} analysis (2-3 sentences)"
}

Status meanings:
- "green" = Healthy - normal ${category} operation, no issues detected
- "amber" = Minor Issue - some ${category} irregularity detected, should be monitored or checked soon
- "red" = Critical Failure - serious ${category} problem detected, immediate attention required`;

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                { text: prompt },
                {
                  inline_data: {
                    mime_type: mimeType,
                    data: base64Audio,
                  },
                },
              ],
            },
          ],
          generationConfig: {
            temperature: 0.4,
            topK: 32,
            topP: 1,
            maxOutputTokens: 1024,
          },
        }),
      }
    );

    const result: GeminiResponse = await response.json();

    if (result.error) {
      console.error("Gemini API error:", result.error.message);
      return simulatedAnalysis(data, source);
    }

    const responseText = result.candidates?.[0]?.content?.parts?.[0]?.text;
    
    if (!responseText) {
      console.error("No response from Gemini");
      return simulatedAnalysis(data, source);
    }

    const analysis = parseGeminiResponse(responseText);

    return {
      id: crypto.randomUUID(),
      timestamp: Date.now(),
      status: analysis.status,
      signature: analysis.signature,
      recommendation: analysis.recommendation,
      source,
      duration: data.size > 0 ? Math.round(data.size / 16000) : 10,
    };
  } catch (error) {
    console.error("Error analyzing audio with Gemini:", error);
    return simulatedAnalysis(data, source);
  }
}

// Fallback simulated analysis when no API key is available
async function simulatedAnalysis(
  data: Blob | File,
  source: "live" | "uploaded",
  category: DiagnosticCategory = "engine"
): Promise<DiagnosticResult> {
  // Simulate 3-second analysis time
  await new Promise((resolve) => setTimeout(resolve, 3000));

  const categoryLabel = category.charAt(0).toUpperCase() + category.slice(1);

  const SIGNATURES: Record<DiagnosticCategory, Record<DiagnosticStatus, string[]>> = {
    engine: {
      green: ["Normal Engine Idle Pattern", "Consistent Combustion Rhythm", "Smooth Valve Train Operation"],
      amber: ["Slight Belt Oscillation", "Minor Timing Irregularity", "Intermittent Lifter Tick"],
      red: ["Severe Knock Detected", "Metal-on-Metal Contact", "Irregular Combustion Pattern"],
    },
    transmission: {
      green: ["Smooth Gear Engagement", "Normal Shift Pattern", "Clean Torque Converter Operation"],
      amber: ["Slight Shift Hesitation", "Minor Gear Whine", "Soft Engagement Detected"],
      red: ["Grinding During Shifts", "Severe Slippage Detected", "Torque Converter Shudder"],
    },
    brakes: {
      green: ["Normal Brake Operation", "Clean Pad Contact", "Smooth Caliper Action"],
      amber: ["Light Brake Squeal", "Early Pad Wear Indicator", "Minor Pulsation Detected"],
      red: ["Metal-on-Metal Grinding", "Severe Rotor Scoring", "Caliper Seizure Sounds"],
    },
    suspension: {
      green: ["Normal Suspension Travel", "Smooth Strut Operation", "Clean Joint Articulation"],
      amber: ["Minor Clunk Over Bumps", "Slight Strut Squeak", "Early Bushing Wear"],
      red: ["Severe Ball Joint Knock", "Failed Strut Mount", "Broken Spring Detected"],
    },
    hvac: {
      green: ["Normal Blower Operation", "Clean Compressor Cycling", "Smooth Airflow"],
      amber: ["Slight Blower Vibration", "Minor Actuator Click", "Reduced Airflow Sound"],
      red: ["Compressor Failure Sound", "Bearing Grinding", "Seized Blower Motor"],
    },
  };

  const RECOMMENDATIONS: Record<DiagnosticCategory, Record<DiagnosticStatus, string[]>> = {
    engine: {
      green: ["Your engine sounds healthy. Continue regular maintenance schedule.", "All engine components operating normally. Next check in 30 days."],
      amber: ["Minor engine irregularity detected. Schedule inspection within 2 weeks.", "Consider checking timing belt and accessory drive components."],
      red: ["Immediate attention required. Engine knock or valve train issues detected. Consult a mechanic immediately."],
    },
    transmission: {
      green: ["Transmission operating smoothly. Maintain regular fluid changes.", "Gear engagement and shifts within normal parameters."],
      amber: ["Minor transmission anomaly detected. Check fluid level and condition.", "Consider transmission service at next maintenance interval."],
      red: ["Critical transmission issue detected. Avoid driving until inspected. Possible internal damage."],
    },
    brakes: {
      green: ["Brake system sounds healthy. Continue regular inspections.", "Pad and rotor condition appears normal."],
      amber: ["Brake wear detected. Schedule pad inspection within 1,000 miles.", "Consider brake service soon to prevent rotor damage."],
      red: ["Critical brake issue. Metal contact detected. Do not drive. Immediate brake service required."],
    },
    suspension: {
      green: ["Suspension operating normally. No unusual wear detected.", "All suspension components within normal parameters."],
      amber: ["Minor suspension noise detected. Inspect bushings and ball joints.", "Schedule alignment check at next service."],
      red: ["Critical suspension failure detected. Vehicle unsafe to drive. Immediate inspection required."],
    },
    hvac: {
      green: ["Climate system operating normally. No issues detected.", "Blower and compressor functioning within parameters."],
      amber: ["Minor HVAC noise detected. Check cabin air filter and blower motor.", "Consider AC system service at next maintenance."],
      red: ["Critical HVAC failure. Compressor or blower motor failure detected. Service required."],
    },
  };

  function getRandomItem<T>(arr: T[]): T {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  function generateRandomStatus(): DiagnosticStatus {
    const rand = Math.random();
    if (rand < 0.5) return "green";
    if (rand < 0.85) return "amber";
    return "red";
  }

  const status = generateRandomStatus();
  const signatures = SIGNATURES[category][status];
  const recommendations = RECOMMENDATIONS[category][status];

  return {
    id: crypto.randomUUID(),
    timestamp: Date.now(),
    status,
    signature: getRandomItem(signatures),
    recommendation: getRandomItem(recommendations),
    source,
    duration: data.size > 0 ? Math.round(data.size / 16000) : 10,
  };
}
